<?php
session_start();
include("Master.php");
session_start();
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
require("InventoryClass.php");
parse_str($_SERVER['QUERY_STRING']);
?>
<html>
    <header>  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
       <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
    <br/>
    <form action="" method="POST">    
    <br/>

     <a href="RoomsInventory.php"> <input type="submit" name="InventorySummary" value="Inventory Summary" class="w3-button w3-black w3-round-xxlarge" /></a>
     <a href="RoomsInventory.php"> <input type="submit" name="RoomAssets" value="View Room Assets" formaction = "RoomsInventory.php"  class="w3-button w3-black w3-round-xxlarge" /></a>
   
    </form>
    </body>
	   </html>

<?php
$DBconn = new InventoryClass();
$DBconn->connect();
$DBconn->readInventory();
$DBconn->close();
?>

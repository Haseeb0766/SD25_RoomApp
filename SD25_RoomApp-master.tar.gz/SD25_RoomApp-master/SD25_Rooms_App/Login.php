<?php
session_start();
session_unset();
session_destroy();
?>
<html>
    <title>Login </title>
  
        <link rel="stylesheet" type="text/css" href="Login.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" />
<a id="popuplink" href="#inline" style="display:none;"></a>
<form action="check_Login.php" method="POST">
<div id="divs" class="div1"/>
<div class="bg">
  <div class="wrapper">
  <div class="login-box">
    <h2>Username</h2>
    <input type="text" name="username"  />
    <h2>Password</h2>
    <input type="password"  name="Password" />
    <input type="submit" name="Login" value="Login"  >
    </br>
     <p name="ErrorMsg"  ><?php echo $_GET['ErrorMsg']; ?> </p>
    <a href="PasswordReset.php">Forgot your password?</a>
    </br>
 
    <div class="pointer"></div>
  </div>
    
  <div class="branding"><p>Robertson Bot</h1></p>
    
  </div>
  
  
</div>
</div>
<div id="divs" class="div2">
    
</div>
<div id="inline" style="display:none;text-align:center;">

<h3 style="margin-top:20px;">Welcome to Robertson Bot</h3>
<p>Here you will be able to Manage Robertson college Rooms and all the Facilities Requirements </p>
<p><a href="javascript:;" onclick="jQuery.fancybox.close();" style="background-color:#333;padding:5px 10px;color:#fff;border-radius:5px;text-decoration:none;">Close</a></p>
</div>
</form>
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.0/jquery.cookie.js"></script>
<script>
jQuery(document).ready(function () {
    function openFancybox() {
        setTimeout(function () {
            jQuery('#popuplink').trigger('click');
        }, 500);
    };
    var visited = jQuery.cookie('visited');
    if (visited == 'yes') {
        openFancybox();  // second page load, cookie active
    } else {
        openFancybox(); // first page load, launch fancybox
    }
    jQuery.cookie('visited', 'yes', {
        expires: 365 // the number of days cookie  will be effective
    });
    jQuery("#popuplink").fancybox({modal:true, maxWidth: 400, overlay : {closeClick : true}});
});
</script>

</body>
</html>

<?php 
session_start();
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
require("InstructorClass.php");
parse_str($_SERVER['QUERY_STRING']);
if(isset($_POST["Insert"])){    
  $Email =  $_POST["Email"];
   require_once("Mail.php");
    $Password = (rand(100000000,999999999));
 $from = "haseeb.ahmad@robertsoncollege.net";
 $to = $Email;
 $subject = "Hi!";
 $body = "Hello there:,\n\nThis is Admin of Robertson Bot\n I have created your account as an Instructor. Please use this Password to log in." . $Password . "\n Link to the Robertson Bot http://localhost/SD25_Rooms_App/Login.php";
 
 $host = "ssl://smtp.gmail.com";
 $username = "haseeb.ahmad@robertsoncollege.net";
 $password = "haseebaqib1";
 
 $headers = array (
   'From' => $from,
   'To' => $to,
   'Subject' => $subject);

 $smtp = Mail::factory('smtp', array (
     'host' => $host,  
     'port' => '465',   
     'auth' => true,
     'username' => $username,
     'password' => $password));
 
 $mail = $smtp->send($to, $headers, $body);
 
 if (PEAR::isError($mail)) {
   echo("<p>" . $mail->getMessage() . "</p>");
  } else {
   echo("<p>Message successfully sent!</p>");
  }

    
    $firstName =  $_POST["firstName"];
    $LastName = $_POST["LastName"];
    $Campus =  $_POST["Campus"];
    $Description = $_POST["description"];
    $DBconn = new InstructorClass();
    $DBconn->connect();
   $result = $DBconn->Insert($Email,$firstName,$LastName,$Campus,$Description,$Password); 
    $DBconn->close();
     if($result == 'Insert Successful')
    {
         header("location:Management.php");  
    }
}
if(isset($_POST["SubmitUPD"]))
{
    $Email =  $_POST["Email"];
    $firstName =  $_POST["firstName"];
    $LastName = $_POST["LastName"];
    $Campus =  $_POST["Campus"];
    $Description = $_POST["description"];
    $DBconn = new InstructorClass();
    $DBconn->connect();
  $result =  $DBconn->Update($Email,$firstName,$LastName,$Campus,$Description); 
    $DBconn->close();
    if($result == 'Update Complete')
    {
         header("location:Management.php");  
    }
    else 
    {
      echo "Something Went Wrong";
    }
}
if(isset($_POST["SubmitDEL"]))
{ 
 
  
$DBconn = new InstructorClass();
    $DBconn->connect();
    $Email =  trim($Email); 
    
    $result = $DBconn->Delete($Email);  
    
    $DBconn->close();
    if($result == 'Instructor Deleted')
    {
      header("location:Management.php");  
    }
    else {
      echo 'Something Went Wrong';
    }
  
}

?>
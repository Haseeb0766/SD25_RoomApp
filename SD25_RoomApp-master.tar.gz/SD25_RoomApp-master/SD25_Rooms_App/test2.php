<?php
 require_once("Mail.php");
 $from = "haseeb.ahmad@robertsoncollege.net";
 $to = "ahmadhaseeb33@gmail.com";
 $subject = "Hi!";
 $body = "Hi,\n\nHow are you?";
 
 $host = "ssl://smtp.gmail.com";
 $username = "haseeb.ahmad@robertsoncollege.net";
 $password = "haseebaqib1";
 
 $headers = array (
   'From' => $from,
   'To' => $to,
   'Subject' => $subject);

 $smtp = Mail::factory('smtp', array (
     'host' => $host,  
     'port' => '465',   
     'auth' => true,
     'username' => $username,
     'password' => $password));
 
 $mail = $smtp->send($to, $headers, $body);
 
 if (PEAR::isError($mail)) {
   echo("<p>" . $mail->getMessage() . "</p>");
  } else {
   echo("<p>Message successfully sent!</p>");
  }
  echo (rand(100000000,999999999));
 ?>
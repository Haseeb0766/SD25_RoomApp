<?php
session_start();
include("Master.php");
$UserType = $_SESSION['UserType'];
$Email = $_SESSION['username'];
require("RequestClass.php");
parse_str($_SERVER['QUERY_STRING']);
$DBconn = new RequestClass();
    $DBconn->connect();
    if($UserType == "Admnistrator")
    {
$DBconn->ViewRequests();
    }
    else{
        $DBconn->ViewMyRequests($Email);
    }
$DBconn->close();
?>
<html>
<head>
      <link rel="stylesheet" type="text/css" href="Requests.css">
    </head>
    <body>

 </body>
        </html>

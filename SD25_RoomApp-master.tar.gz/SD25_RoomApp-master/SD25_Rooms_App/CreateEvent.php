<html>
<head></head>
<body>
<table><tr><td><input type="button" id="ViewEvents" value="View Events"/></td>
<td><input type="button" id="InsertNew" value="Insert New Events" onclick="ViewEvents()" /></td></tr></table>
<div id="ViewEvent" style="visibility: hidden;"  >Here you will View all the events </div>
<div id="create" style="visibility: hidden;" >Here you will create the events</div> 
<script type="text/javascript">
function ViewEvents(){
document.getElementById('ViewEvent').style.display = 'block';
}
</script>
</body>

</html>

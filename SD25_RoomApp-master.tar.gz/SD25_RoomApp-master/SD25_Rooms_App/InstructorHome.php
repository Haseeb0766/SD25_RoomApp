<?php
session_start();
include("Master.php");
if(  $_SESSION['UserType'] == "Admnistrator")
{
  header("location: floors.php");
}
else if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
echo '<h1 style="text-align:center;" > Welcome Back ' . $_SESSION['FirstName'] . '</h1>';
?>
<html>
<header>  
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</header>
<body>
<div id="Events" style=" position: absolute;
  width: 300px;
  height: 200px;
  z-index: 15;
  top: 50%;
  left: 50%;
  margin: -100px 0 0 -150px;
 " >
 <a href="http://localhost/SD25_Rooms_App/MyRequests.php"><input type="button" value="My Requests" class="w3-button w3-black w3-round-xxlarge"  /> </a>
 <a href="http://localhost/SD25_Rooms_App/MyGroups.php">  <input type="button" value="My Groups" class="w3-button w3-black w3-round-xxlarge"/></a>
 
</div>
</body>
</html>
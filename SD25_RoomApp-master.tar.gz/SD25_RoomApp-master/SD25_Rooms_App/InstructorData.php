<html>
<body>


<div id="Inatkes" >
<table>
<tr><td>Intake #1</td></tr>
<tr><td>Intake#2</td></tr>  
</table>




</body>
</html>
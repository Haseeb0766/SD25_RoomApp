<?php 
session_start();
include("Master.php");
require("RoomsClass.php");
?>

<?php
function ExploreFloor($FloorID){
    //$RoomName =  trim($RoomName);
    $DBconn = new RoomsClass();
    $DBconn->connect();
    $Rooms = $DBconn->ReadOneFloor($FloorID);
    $DBconn->close();
    return $Rooms;
}
?>

<html>
  <head>
    <meta charset="utf-8">
    <title>data</title>
	<script src="http://labratrevenge.com/d3-tip/javascripts/d3.tip.v0.6.3.js"></script> 
    <link rel="stylesheet" href="normalize.css">
    <style>
	  .tooltip{
position: absolute;	
  text-align: center;	
  width: 13%;	
  height:10%;		
  padding: 2vw;	
  font: 1.2vw sans-serif;		
  border: 0px;					
  border-radius: 8px;
  color:black;
  box-shadow: -3px 3px 15px #888888;
  opacity:0;	

}
</style>
<body>
<div style=" border: solid gray 1px; border-radius: 50px;
 background:blur(5px); background-color:white;  width: 30%; margin: 90px auto; padding: 50px; ">
<form action="" method="POST">
<br></br>
<table>
<tr>
<td>
<select id='colorselector' name='colorselector'>
<option value='None'>Select Campus</option>
<option value='Notre Dame Campus'>Notre Dame Campus</option>
<option value='Main Street Campus'>Main Street Campus</option>
</select>
</td>
<td>
<select id='NortdameCampus' name='NortdameCampus'>
<option value='None'>Select Floor</option>
<option value='1'>Lower Level</option>
<option value='2'>Floor 1</option>
<option value='3'>Floor 2</option>
<option value='4'>Floor 3</option>
<option value='5'>Floor 4</option>
<option value='6'>Floor 5</option>
</select>
<select id='MainstCampus' name='MainstCampus' style='display: none'>
<option value='None'>Select Floor</option>
<option value='7'>Floor 3</option>
<option value='8'>Floor 13</option>
</select>
</td>
<td>
<input type="submit" name="ExploreFloor" value="Explore Floor">
</td>
</tr>
</table>
</form>
</div>
<script src="http://d3js.org/d3.v3.min.js"></script>

    <div id = "svgContent"></div>

<?php
if (isset($_POST['ExploreFloor'])) {
    echo 'test';
    if($_POST["colorselector"]=="Notre Dame Campus"){
        //echo 'test1';
        //echo $_POST["NortdameCampus"];
        $RoomsArray = ExploreFloor($_POST["NortdameCampus"]);
    }
    else if($_POST["colorselector"]=="Main Street Campus"){
        //echo 'test2';
        $RoomsArray = ExploreFloor($_POST["MainstCampus"]);
    }
    else{
        //echo 'test3';
        $RoomsArray = [];
    }
    //$_SESSION['RoomsArray'][] = $RoomsArray;
    //echo $RoomsArray[0][1];
    //echo $_SESSION['RoomsArray'][][];
    //echo '<script type="text/javascript">JSExploreFloor()</script>';
  }
?>
<script type="text/javascript">
var jsRooms_Array = JSON.parse('<?php echo json_encode($RoomsArray)?>');
//var jsRoms_Array = json_encode('<%= Session.getAttribute("RoomsArray") %>');
//alert(jsRooms_Array.length);
//alert(jsRooms_Array[0][1]);
    var data = [];
    var obj = new Object();    
    for(i=0; i<jsRooms_Array.length; i++){
        //alert(i);
        obj = {            
            RoomNumber: jsRooms_Array[i][0],
            RoomName: jsRooms_Array[i][1],
            Capacity: jsRooms_Array[i][2]
        };
        //alert(obj);
        data.push(obj);        
    }
/*var data = [{"Room":jsRooms_Array[0][0],"Capacity":jsRooms_Array[0][2]},
            {"Floor":"3","population":3394},
            {"Floor":"12 yrs & Above –Below 16 yrs","population":429},
            {"Floor":"16 yrs & Above – Below 18 yrs","population":568},
            {"Floor":"18 yrs & Above – Below 30 yrs","population":0},          
			{"Floor":"30 yrs & Above – Below 45 yrs","population":0},
            {"Floor":"45 yrs & Above – Below 60 yrs","population":0},
            {"Floor":"60 yrs & Above","population":1116}];
            alert(data);*/
var margin = {top:40,left:40,right:40,bottom:40};
width = 300;
height = 300;
radius = Math.min(width-100,height-100)/2;
var color = d3.scale.category10();
var arc = d3.svg.arc()  
         .outerRadius(radius -230)
         .innerRadius(radius - 50)
		 .cornerRadius(20);
var arcOver = d3.svg.arc()  
.outerRadius(radius +50)
.innerRadius(0);

var a=width/2 - 20;
var b=height/2 - 90;
var svg = d3.select("#svgContent").append("svg")
          .attr("viewBox", "0 0 " + width + " " + height/2)
          .attr("preserveAspectRatio", "xMidYMid meet")
          .append("g")
          .attr("transform","translate("+a+","+b+")");

		  div = d3.select("body")
.append("div") 
.attr("class", "tooltip");
var pie = d3.layout.pie()
          .sort(null)
          .value(function(d){return d.Capacity;})
		  .padAngle(.02);
var g = svg.selectAll(".arc")
        .data(pie(data))
        .enter()
        .append("g")
        .attr("class","arc")
         .on("mousemove",function(d){
        	var mouseVal = d3.mouse(this);
        	div.style("display","none");
        	div
        	.html("Room #:"+d.data.RoomNumber+"</br>"+"Name:"+d.data.RoomName+"</br>"+"Capacity:"+d.data.Capacity)
            .style("left", (d3.event.pageX+12) + "px")
            .style("top", (d3.event.pageY-10) + "px")
            .style("opacity", 1)
            .style("display","block");
        })
        .on("mouseout",function(){div.html(" ").style("display","none");});
        
		g.append("path")
		.attr("d",arc)
		.style("fill",function(d){return color(d.data.RoomNumber);})
		 .attr("d", arc);
/*
		            svg.selectAll("text").data(pie(data)).enter()
		             .append("text")
		             .attr("class","label1")
		             .attr("transform", function(d) {
		      		   var dist=radius+15;
		    		   var winkel=(d.startAngle+d.endAngle)/2;
		    		   var x=dist*Math.sin(winkel)-4;
		    		   var y=-dist*Math.cos(winkel)-4;
		    		   
		    		   return "translate(" + x + "," + y + ")";
		            })
		            .attr("dy", "0.35em")
		            .attr("text-anchor", "middle")
		            
		    	    .text(function(d){
		    	      return d.value;
		    	    });*/
</script>

</body>
<script type="text/javascript">
  $(document).ready(function () {
    $('#colorselector').change(function() {
      if ($(this).val() == 'Notre Dame Campus') {
        $('#NortdameCampus').show();
        $('#MainstCampus').hide();
        
      } else if ($(this).val() == 'Main Street Campus') {
        $('#MainstCampus').show();
        $('#NortdameCampus').hide();
      }
      else{
           $('#MainstCampus').hide();
           $('#NortdameCampus').hide();
      }
    });
  });
</script>
</html>


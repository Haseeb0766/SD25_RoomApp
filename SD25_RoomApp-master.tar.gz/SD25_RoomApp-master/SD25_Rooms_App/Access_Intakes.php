<?php
session_start();
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
else if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
require("IntakeClass.php");
parse_str($_SERVER['QUERY_STRING']);
$IntakeID =  trim($IntakeID);
if(isset($_POST["Save"])){
 $DBconn = new InTakeClass();
$DBconn->connect();
$DBconn->DeleteIntake($IntakeID);
$DBconn->close();
header("location: InTakes.php");
}
else 
{
    
   $IntakeID =  $_POST["InTakeID"];
     $StartDate =  $_POST["StartDate"];
       $EndDate =  $_POST["EndDate"];
         $StartTime =  $_POST["StartTime"];
           $EndTime =  $_POST["EndTime"];
             $InstructorEmail =  $_POST["InstructorEmail"];
               $NumberofStudents =  $_POST["NumberofStudents"];
                 $Description =  $_POST["Description"];
     

 $DBconn = new InTakeClass();
$DBconn->connect();
$DBconn->UpdateEdit($IntakeID,$StartDate,$EndDate,$StartTime,$EndTime,$InstructorEmail,$NumberofStudents,$Description);
$DBconn->close();
header("location:InTakes.php");

}
?>
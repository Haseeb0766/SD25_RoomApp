<?php 
session_start();
include("Master.php");
require("IntakeClass.php");
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
?>
<html>
    <header>  
         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
         <link rel="stylesheet" type="text/css" href="Button.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
    </br>
    </br>
    <div>
    <a  href="#InsertInTake"><input type="button" class="Button" value="Insert"/></a></div>
    <?php $DBconn = new InTakeClass();
$DBconn->connect();
$DBconn->ReadAllIntakes();
$DBconn->close();?></div>
   <div id="InsertInTake" class="overlay">
	<div class="popup">
		<a class="close" href="#">&times;</a>
     <form action="Access_Intake.php" method="POST" >
     <div>
     (IntakeID, StartDate, EndDate, StartTime, EndTime, InstructorEmail, NumOfStudents, Description)
<table>
<tr>
<td>Intake ID</td>
<td><input type="text" name="InTakeID"/> </td>
</tr>
<tr>
<td>Start Date:</td>
<td><input type="Date" name="StartDate"/> </td>
</tr>
<tr>
<td>End Date</td>
<td><input type="Date" name="EndDate"/></td>
</tr>
<tr>
<td>Start Time</td>
<td><input type="Time" name="StartTime"/></td>
</tr>
<tr>
<tr>
<td>End Time</td>
<td><input type="Time" name="EndTime"/> </td>
</tr>
<tr><td>Select Instructor </td>
<td>
<select name="InstructorEmail">
<?php 
$DBconn = new InTakeClass();
$DBconn->connect();
$Instructors = $DBconn->getInstructors(); 
$DBconn->close();
for($i=0;$i<count($Instructors);$i++){
echo "<option value='{$Instructors[$i][0]}'>{$Instructors[$i][1]}</option>";
}
?>
</select></td>
</tr>
<tr>
<td>Number of Students</td>
<td><input type="Number" name="NumberofStudents"/></td>
</tr>
<tr>
<td>Description</td>
<td><textarea name="Description"/></textarea></td>
</tr>
</table>
     </div>
<input type="Submit" Class="Button" name="Save"  value="Save" >
</form>
     </div>
     </div>
    </body>
    </html>
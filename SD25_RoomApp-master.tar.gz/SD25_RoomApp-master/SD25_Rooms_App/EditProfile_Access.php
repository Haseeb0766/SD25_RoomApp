<?php
session_start();
include("Master.php");
require("LoginClass.php");
if(isset($_POST["SaveProfile"])){
  $target_dir = "Images/";
  $target_file = $target_dir . basename($_FILES["ProfilePicture"]["name"]);
  echo "</br>";
  //echo $target_file;
  $uploadOK = 1;
  $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
  echo "</br>";
  //echo $imageFileType;
    $check = getimagesize($_FILES["ProfilePicture"]["tmp_name"]);
    if($check !== false){
      //echo "File is an image - " .$check["mime"] . ".</br></br/>  ";
      $uploadOK = 1;
    } else {
      //echo "File is not an image.";
      $uploadOK = 0;
    }

  if(file_exists($target_file)){
    //echo "Sorry, file already exists.";
    $uploadOK = 2;
  }
  //echo $_FILES["fileToUpload"]["size"];
  if(empty($_FILES["ProfilePicture"]['name'])){
    //echo "Sorry, your file is empty.";
    $uploadOK = 0;
  }

  if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
  && $imageFileType != "gif"){
    //echo "Sorry, only JPG, JPEG, PNG, & GIF files are allowed.";
    $uploadOK = 0;
  }
  if($uploadOK == 0){
    //echo "Sorry, your file was not uploaded.";
    $fileName = "default-user-image.png";
  } else if($uploadOK == 2){
    $fileName = basename( $_FILES["ProfilePicture"]["name"]);
  }
  else {
    if(move_uploaded_file($_FILES["ProfilePicture"]["tmp_name"], $target_file)){
      $fileName = basename( $_FILES["ProfilePicture"]["name"]);
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
  }
    $Email =  $_SESSION['username'];
    $FirstName =  $_POST["FirstName"];
    $LastName =  $_POST["LastName"];
    $DBconn = new LoginClass();
    $DBconn->connect();
    $DBconn->EditProfile($Email,$FirstName,$LastName,$fileName);
    $DBconn->close();
}
else if(isset($_POST["SavePwrd"])){
    echo 'test';
    $Email =  $_SESSION['username'];
    $OldPwrd =  $_POST['CurrentPwrd'];
    $NewPwrd =  $_POST["NewPwrd"];
    $ReNewPwrd =  $_POST["ReNewPwrd"];
    if($NewPwrd != $ReNewPwrd){        
        header("Location:EditProfile.php?action=actionCheck&error=New passwords do not match");
    }
    else {
        $DBconn = new LoginClass();
    $DBconn->connect();
    $DBconn->ChangePassword($Email, $OldPwrd, $NewPwrd);
    $DBconn->close();
    }
    
}
?>
<html>
    <header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
	   </html>

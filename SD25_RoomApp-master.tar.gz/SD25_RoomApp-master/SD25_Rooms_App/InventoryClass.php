<?php
class InventoryClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;
    private $Asset = array(6);

    function __construct (){}

    function connect (){
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);   
                                              
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }

    function close()
    {
        $this->conn->close();
    }

    function readAllRooms (){
        $sql = "call spRoom(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'readAllRooms')";         
        $result = $this->conn->query($sql);    
        $RoomsArray = array(array(), array());
        $count = 0;
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $RoomsArray[$count][0] = $row["RoomNumber"]; 
                $RoomsArray[$count][1] = $row["RoomName"]; 
                $count = $count + 1;
            }
        }
        return $RoomsArray;
    }

    function readInventory() 
    {
        $count = 0;        
        $sql = "call spAsset(NULL, NULL, NULL, NULL, NULL, 'readAllAssetQuantity')";         
        $result = $this->conn->query($sql);    
        if($result->num_rows > 0)        {            
             $AssetTable = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Asset Name</th>
                        <th>Quantity in Stock</th>
                        <th>Quantity in Room</th>
                        <th></th>                  
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $Asset[$count] = $row["QtyInStock"];
            $count = $count + 1;
                $AssetTable = $AssetTable . "<tr><td>"  . $row["AssetName"] . "</td>" .
                                                     "<td>" . $row["QtyInStock"] . "</td>" . 
                                                     "<td>" . $row["QtyInRoom"]. "</td>" .                                                    
                                                     "<td><input type='Submit' name='ViewAssetInRooms' value='View Asset In Rooms'" 
                                                     ."formaction='EditAssetInStock.php?". "AssetID=".$row['AssetID'] 
                                                     ."&AssetName=".$row['AssetName'] 
                                                     ."&QtyInStock=".$row['QtyInStock']
                                                     ."&QtyInRoom=".$row['QtyInRoom']                              
             ."'/></td></tr>";          
            }            
            $AssetTable = $AssetTable . "</tbody></table></form>";
            $EditButton = "<form action='' method='POST'><input type='submit'  class='w3-button w3-black w3-round-xxlarge' name='EditAssetInStock' value='Edit Asset In Stock'";
            $EditButton = $EditButton . "formaction='EditAssetInStock.php?"
                                                     ."action=UpdateStock"
                                                     ."&ChairQTY=".$Asset['0'] 
                                                     ."&TableQTY=".$Asset['1'] 
                                                     ."&PowerCordQTY=".$Asset['2']
                                                     ."&ProjectorQTY=".$Asset['3']
                                                     ."&MonitorQTY=".$Asset['4']
                                                     ."&RoomComputerQTY=".$Asset['5'] . "'/></form>";
            echo $EditButton;
            echo $AssetTable;           
        }
    }

    function readAssetInRooms($RoomName) 
    {
        $AssetTable = "";
            $sql = "call spAsset(NULL, NULL,'" . $RoomName . "', NULL, NULL, 'readRoomAssetQuantity')";
            $result = $this->conn->query($sql);    
            if($result->num_rows > 0){   
                $AssetTable = $AssetTable . "<tr><td>" . $RoomName . "</td>";  
                $count = 0;     
                $rowDetails = array();            
                while($row = $result->fetch_assoc()){
                    if($count == 0){
                        if($row["AssetName"] == "Chair"){
                            $AssetTable = $AssetTable . "<td>" . $row["Quantity"] . "</td>";   
                            $rowDetails[0] = $row["Quantity"];
                        }
                        else{
                            $AssetTable = $AssetTable . "<td>0</td>";  
                            $rowDetails[0] = 0; 
                        }
                    }     
                    else if($count == 1){
                        if($row["AssetName"] == "Table"){
                            $AssetTable = $AssetTable . "<td>" . $row["Quantity"] . "</td>";  
                            $rowDetails[1] = $row["Quantity"];   
                        }
                        else{
                            $AssetTable = $AssetTable . "<td>0</td>";   
                            $rowDetails[1] = 0; 
                        }
                    }   
                    else if($count == 2){
                        if($row["AssetName"] == "Power Cord"){
                            $AssetTable = $AssetTable . "<td>" . $row["Quantity"] . "</td>"; 
                            $rowDetails[2] = $row["Quantity"]; 
                        }
                        else{
                            $AssetTable = $AssetTable . "<td>0</td>";   
                            $rowDetails[2] = 0; 
                        }
                    }   
                    else if($count == 3){
                        if($row["AssetName"] == "Projector"){
                            $AssetTable = $AssetTable . "<td>" . $row["Quantity"] . "</td>";  
                            $rowDetails[3] = $row["Quantity"];
                        }
                        else{
                            $AssetTable = $AssetTable . "<td>0</td>"; 
                            $rowDetails[3] = 0;   
                        }
                    }   
                    else if($count == 4){
                        if($row["AssetName"] == "Monitor"){
                            $AssetTable = $AssetTable . "<td>" . $row["Quantity"] . "</td>";  
                            $rowDetails[4] = $row["Quantity"];
                        }
                        else{
                            $AssetTable = $AssetTable . "<td>0</td>";   
                            $rowDetails[4] = 0; 
                        }
                    }   
                    else if($count == 5){
                        if($row["AssetName"] == "Room Computer"){
                            $AssetTable = $AssetTable . "<td>" . $row["Quantity"] . "</td>";  
                            $rowDetails[5] = $row["Quantity"];
                        }
                        else{
                            $AssetTable = $AssetTable . "<td>0</td>";   
                            $rowDetails[5] = 0; 
                        }
                        $AssetTable = $AssetTable . "<td><input type='Submit' name='ViewAssetInRooms' value='Edit Assets'" 
                                                     ."formaction='EditAssetInStock.php?"
                                                     ."action=UpdateRoom"                                                                                                          
                                                     ."&RoomName=".$RoomName 
                                                     ."&AssetID=".$row['AssetID'] 
                                                     ."&ChairQTY=".$rowDetails['0'] 
                                                     ."&TableQTY=".$rowDetails['1'] 
                                                     ."&PowerCordQTY=".$rowDetails['2']
                                                     ."&ProjectorQTY=".$rowDetails['3']
                                                     ."&MonitorQTY=".$rowDetails['4']
                                                     ."&RoomComputerQTY=".$rowDetails['5'] . "'/></form>";
                    }  
                    else {
                        
                    }  
                    $count = $count + 1;              
                }  
                $AssetTable = $AssetTable . "</tr>";
                return $AssetTable;
            }                        
    }
    
    function readAsset($AssetID)
    {
         $sql = "call spAsset(" . $AssetID . ", NULL, NULL, NULL, NULL, 'readAssetQuantity')";
           $result = $this->conn->query($sql);
            if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                          
            }                    
        }
    }

    function UpdateAssetInStock($AssetID, $Quantity){
        $sql = "call spAsset(" . $AssetID . ", NULL, NULL,'" . $Quantity . "', NULL, 'UpdateAssetInStock')";
        //echo "<br></br>" . $sql;
        $result = $this->conn->query($sql);
        if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                if($row["UpdateResult"] == "Update successfull"){
                    header("location:Inventory.php");
                }                       
            }                    
        }
    }

    function UpdateAssetInRoom($RoomName, $AssetID, $Quantity){
        $sql = "call spAsset(" . $AssetID . ", NULL,'" . $RoomName . "','" . $Quantity . "', NULL, 'UpdateAssetInRoom')";
        //echo "<br></br>" . $sql;
        $result = $this->conn->query($sql);
        if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                echo "<br/><br/>" . $row["UpdateResult"];
                if($row["UpdateResult"] == "Update successfull"){
                    header("location:Inventory.php");
                }
                else if($row["UpdateResult"] == "Asset quantity out of stock"){
                    echo "<script>alert('Asset quantity out of stock')</script>";
                }                       
            }                    
        }
    }
}
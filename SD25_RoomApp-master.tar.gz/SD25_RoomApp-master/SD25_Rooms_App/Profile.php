<?php

session_start();
include("Master.php");
require("InstructorClass.php");
$Check = $_SESSION['username'];
if(  $_SESSION['username'] == NULL)
{
header("location: Login.php");
}


$DefaultPic = "";
if($_SESSION['ProfilePicture'] == NULL || $_SESSION['ProfilePicture'] == '')
 {
  $DefaultPic = "Images/default-user-image.png";
 }
 else{
   $DefaultPic = "Images/". $_SESSION['ProfilePicture'];
 }
 echo "<h1 style='text-align:center'>Welcome Back " . $_SESSION['FirstName'] . "</h1>"
?>
<html>
<header>  <link rel="stylesheet" type="text/css" href="Profile.css">
<link rel="stylesheet" type="text/css" href="Button.css"> </header>

<form action="EditProfile.php" method"POST">

<div width="300px" style="float: left;visibility:visible;">
<img src="<?php echo $DefaultPic ?>"  height="200" width="200S" style=" width: 300px;
  height: 300px;
  border-radius: 50%;" />

  <div style="float: right" width ="300px"
  height= "300px"/ id="Profile"  >
  <h1 style="visibility:hidden">Hello Hi </h1>
<table>
	<tr><td><lable>First Name:</lable></td>
  <td><lable> <?php echo $_SESSION['FirstName'] ?></lable></td></tr>
	<tr><td><lable>Last Name:</lable></td>
  <td><lable> <?php echo $_SESSION['LastName'] ?></lable></td></tr>
	</table>
  </br>
    </br>
      </br>
        </br>

<input type="submit" name="UpdProfileBtn" value="Update Profile" class="Button" >
<input type="submit" name="UpdPwrdBtn" value="Change Password" class="Button"  >
</div>
</div>
</form>
</body>
</html>

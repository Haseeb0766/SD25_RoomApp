<?php
session_start();
include("Master.php");
require("InventoryClass.php");
//parse_str($_SERVER['QUERY_STRING']);
?>
<html>
<header> <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"></header>
<body>
</br>
</br>
 <a href="Inventory.php"> <input type="submit" name="InventorySummary" value="Inventory Summary" class="w3-button w3-black w3-round-xxlarge" /></a>
     <a href="RoomsInventory.php"> <input type="submit" name="RoomAssets" value="View Room Assets" formaction = "RoomsInventory.php"  class="w3-button w3-black w3-round-xxlarge" /></a>
     </body>
</html>
<?php
$DBconn = new InventoryClass();
$DBconn->connect();
$AllRooms = $DBconn->readAllRooms();
//echo "<br/>" . count($AllRooms);
$DBconn->close();
$AssetTable = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Room Name</th>
                        <th>Chairs</th>
                        <th>Tables</th>
                        <th>Power Cords</th>
                        <th>Projectors</th>
                        <th>Monitors</th>
                        <th>Room Computers</th>     
                        <th></th>                                    
                    </tr>
                </thead>
                <tbody>";   
for($i=0; $i<count($AllRooms); $i++){
    $DBconn->connect();
    $Assets = $DBconn->readAssetInRooms($AllRooms[$i][1]);    
    $DBconn->close();
    $AssetTable = $AssetTable . $Assets;
}
$AssetTable = $AssetTable . "</tbody></table></form>";
//echo htmlspecialchars($AssetTable);
echo $AssetTable;
?>

<html>
    <header>  
       <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>  
    <br/>  
    </body>
	   </html>

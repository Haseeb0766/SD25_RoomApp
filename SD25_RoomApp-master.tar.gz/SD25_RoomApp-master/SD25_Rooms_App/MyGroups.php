<?php
include("Master.php");
require("IntakeClass.php");
session_start();
$InstructorEmail = $_SESSION['username'];
$DBconn = new InTakeClass();
 $DBconn->connect();
 $DBconn->myGroups($InstructorEmail);
$DBconn->close();
?>
<html>
<head>
      <link rel="stylesheet" type="text/css" href="Requests.css">
    </head>
    <body>

 </body>
        </html>
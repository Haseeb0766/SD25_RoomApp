<?php
class InstructorClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}
    function connect (){
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);   
                                              
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }
    function close()
    {
        $this->conn->close();
    }
    function readInstructor() 
    {
        
           $sql = "call spUser (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,NULL, 'readAll' )";
    
       
        $result = $this->conn->query($sql);
    
 
        if($result->num_rows > 0)
        {            
             $InstructorTable = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>First Name </th>
                        <th> Last Name</th>
                        
                      <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $InstructorTable = $InstructorTable . "<tr><td>"  . $row["Email"] . "</td>" .
                                                     "<td>" . $row["FirstName"] . "</td>" . 
                                                     "<td>" . $row["LastName"]. "</td>" .                                                    
                                                     "<td><input type='Submit' name='edit' value='Edit'" 
                                                     ."formaction='ProfileUpdate.php?"
                ."Email=".$row['Email']
                ."&action=". $row['edit']
                ."&FirstName=". $row['FirstName']
                ."&LastName=". $row['LastName']
                ."&CampusID=". $row['CampusID']
                ."&Description=". $row['Description']                
             ."'/></td>"
            ."<td><input type='Submit' name='SubmitDEL' value='Delete'"
            ."formaction='Acces_Instructor.php?"
                ."Email=".$row['Email']                              
             ."'/></td></tr>";               
            }            
            $InstructorTable = $InstructorTable . "</tbody></table></form>";
            echo $InstructorTable; 
          
        }
    }

    

    function Insert ($Email,$firstName,$LastName,$Campus,$Description,$NewPass)
    {
        $CampusID = 0;
        switch($Campus){
            case 'Campus 1': $CampusID = 1;
            break;
            case 'Campus 2': $CampusID = 2;
            break;
            default: $CampusID = 0;
            break;
        }
     $sql = "call spUser ('" . $Email . "','" . $firstName . "','" .  $LastName . "', 'Instructor','" .  $CampusID . "','" .  $Description . "'," . $NewPass .",NULL, 'Instructor' , 'signup')";
 
        $this->conn->query($sql);
return 'Insert Successful';
    }
    function Update ($Email,$firstName,$LastName,$Campus,$Description)
    {
        $CampusID = 0;
        switch($Campus){
            case 'Campus 1': $CampusID = 1;
            break;
            case 'Campus 2': $CampusID = 2;
            break;
            default: $CampusID = 0;
            break;
        }
     $sql = "call spUser ('" . $Email . "','" . $firstName . "','" .  $LastName . "', NULL,'" .  $CampusID . "','" .  $Description . "',NULL, NULL, NULL , 'u')";
     echo $sql;
        $this->conn->query($sql);
        return 'Update Complete';
    }
    function Delete ($Email)
    {        
     $sql = "call spUser ('" . $Email . "',NULL,NULL, NULL,NULL,NULL, NULL, NULL,NULL , 'd')";   
            
        $this->conn->query($sql);
        return 'Instructor Deleted';
    }
    function ResetPassword($Email,$password)
    {
      
        $sql = "call spUser ('" . $Email . "',NULL,NULL, NULL,NULL,NULL,'". $password ."', NULL,NULL , 'u')";   
        echo $sql;
        $this->conn->query($sql);
        return "Success";
    }
}
    
<?php
session_start();
include("Master.php");
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
else if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
echo "</br>";
echo "</br>";
echo "</br>";
echo "</br>";
echo "<h1 style='text-align:center'>Welcome back " . $_SESSION["FirstName"] . "</h1>";
?>
<html>

    <head>
    <script src="Scripts/jquery-3.1.1.js"></script>
     <link rel="stylesheet" type="text/css" href="TestStyle.css">  
     <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
     </head>
    <body>
<div style=" border-radius: 5px;
 background:blur(5px); width: 50%; margin: 90px auto; padding: 50px;" >
 <table>
 <tr><td>
 <a href="http://localhost/SD25_Rooms_App/Inventory.php"><input type="button" value="Assets" class="w3-button w3-black w3-round-xxlarge"/> </a></td><td>
 <a href="http://localhost/SD25_Rooms_App/Management.php"><input type="button" value="Instructors" class="w3-button w3-black w3-round-xxlarge"/></a></td><td>
  <a href="http://localhost/SD25_Rooms_App/Rooms.php"><input type="button" value="Rooms" class="w3-button w3-black w3-round-xxlarge"/></a></td><td>
  <a href="http://localhost/SD25_Rooms_App/DataVisuals.php"><input type="button" value="Data Visual" class="w3-button w3-black w3-round-xxlarge"/></a>
   <a href="http://localhost/SD25_Rooms_App/Supplies.php"><input type="button" value="Supplies" class="w3-button w3-black w3-round-xxlarge"/></a>
    </td></tr></table>
</div>
</body>
</html>
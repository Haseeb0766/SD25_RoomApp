<?php
class SupplyClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}
    function connect (){
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);   
                                              
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }
    function close()
    {
        $this->conn->close();
    }
    function readSupply()
    {
         $sql = "call spSupply(NULL,NULL,NULL,NULL,'readAllSupplies')";
 $result = $this->conn->query($sql);

   if($result->num_rows > 0)
        {            
             $SupplyTable = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Supply ID</th>
                        <th>Supply Name  </th>                        
                       <th>Quantity</th>
                       <th> Description</th>
                        <th></th>
                        
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $SupplyTable = $SupplyTable . "<tr><td>"  . $row["SupplyID"] . "</td>" .
                                                     "<td>" . $row["SupplyName"] . "</td>" . 
                                                     "<td>" . $row["Quantity"]. "</td>" . 
                                                     "<td>" . $row["Description"]. "</td>" .                                                                                                       
                                                     "<td><input type='Submit' name='edit' value='Edit'" 
                                                     ."formaction='EditSupply.php?"
                ."SupplyID=".$row['SupplyID']
                . "&SupplyName=" . $row['SupplyName']
                . "&Quantity=" . $row['Quantity']
                . "&Description=" . $row['Description']          
                                  
             ."'/></td>"
            ."</tr>";               
            }            
            $SupplyTable = $SupplyTable . "</tbody></table></form>";
            echo $SupplyTable; 
        }
          
    }
    function DeleteSupply($SupplyID)
    {
         $sql = "call spSupply('". $SupplyID . "',NULL,NULL,'d')";
         echo $sql;
 $result = $this->conn->query($sql);
    }
    function InsertSupply($SupplyName,$Description,$Quantity)
    {
        $sql = "call spSupply(NULL,'" . $SupplyName . "','" . $Description . "','" . $Quantity . "','c')";
 $result = $this->conn->query($sql);
 return 'Supply inserted';
    }
    function UpdateSupply($SupplyID,$SupplyName,$Description,$Quantity)
    {
         $sql = "call spSupply('". $SupplyID . "','" . $SupplyName . "','" . $Description . "','" . $Quantity . "','u')";
    // echo $sql;
 $result = $this->conn->query($sql);
    }
}
    ?>
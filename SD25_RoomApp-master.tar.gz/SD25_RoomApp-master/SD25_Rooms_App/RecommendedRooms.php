<?php
session_start();
include("Master.php");
require("RoomRecommenderClass.php");
if($_SESSION['RequestType'] != "Room" )
{
  header("location:MyRequests.php");
}
/*parse_str($_SERVER['QUERY_STRING']);
$NumOfStudents = trim($NumOfStudents);
$StartDate = trim($StartDate);
$EndDate = trim($EndDate);
$StartTime = trim($StartTime);
$EndTime = trim($EndTime);*/
$DBconn = new RoomRecommenderClass();
$DBconn->connect();
$Roomss = $DBconn->CompareRoomCapacity($_SESSION["NumOfStudents"]);
$DBconn->close();
$DBconn->connect();
$Rooms = $DBconn->CompareDateAndTime($Roomss, $_SESSION["StartDate"], $_SESSION["EndDate"], $_SESSION["StartTime"], $_SESSION["EndTime"]);
//$Rooms = $DBconn->CompareDateAndTime($Rooms, $StartDate, $EndDate, $StartTime, $EndTime);

//echo "<br/><br/><br/>" . count($Rooms);

$RecommendedRooms = array(array(), array(), array(), array());
$count = 0;
//echo "<br/><br/>" . $count;
for($i=0; $i<count($Rooms); $i++){  
  if($Rooms[$i][3] == 10){
     $RecommendedRooms[$count][0] = $Rooms[$i][0];
     $RecommendedRooms[$count][1] = $Rooms[$i][1];
     $RecommendedRooms[$count][2] = $Rooms[$i][2];
     $RecommendedRooms[$count][3] = $Rooms[$i][3];
     $count = $count + 1;
   }    
}
for($i=0; $i<count($Rooms); $i++){  
  if($Rooms[$i][3] == 7){
     $RecommendedRooms[$count][0] = $Rooms[$i][0];
     $RecommendedRooms[$count][1] = $Rooms[$i][1];
     $RecommendedRooms[$count][2] = $Rooms[$i][2];
     $RecommendedRooms[$count][3] = $Rooms[$i][3];
     $count = $count + 1;
   }    
}
for($i=0; $i<count($Rooms); $i++){  
  if($Rooms[$i][3] == 5){
     $RecommendedRooms[$count][0] = $Rooms[$i][0];
     $RecommendedRooms[$count][1] = $Rooms[$i][1];
     $RecommendedRooms[$count][2] = $Rooms[$i][2];
     $RecommendedRooms[$count][3] = $Rooms[$i][3];
     $count = $count + 1;
   }    
}
//echo "<br/>" . count($RecommendedRooms);
//echo "<br/><br/>" . $count;
$DBconn->connect();
$DBconn->DisplayRecommended($RecommendedRooms);
$DBconn->close();

?>
<html>
<head>
      <link rel="stylesheet" type="text/css" href="Requests.css">
    </head>
    <body>

 </body>
        </html>

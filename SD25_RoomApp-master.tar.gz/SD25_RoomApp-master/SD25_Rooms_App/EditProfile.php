<?php
session_start();
include("Master.php");
parse_str($_SERVER['QUERY_STRING']);
$Error = trim($error);
$ErrorAction = trim($action);
$action = "";
if(isset($_GET["UpdPwrdBtn"]) || $ErrorAction == "actionCheck")
{
$action = "updPwrd";
}
if(isset($_GET["UpdProfileBtn"]))
{
  $action = "updProfile";
}

?>
<html>
<header>  <link rel="stylesheet" type="text/css" href="Profile.css">
<link rel="stylesheet" type="text/css" href="Button.css"> </header>
<body style="background-color:#efeff5">
</br>
</br>
<form action="EditProfile_Access.php"  Method="POST" enctype="multipart/form-data">
<div <?php if($action == "updPwrd" ) echo "style='display: none;'";?>>
<table>
<tr>
<td>First Name:</td><td><input type="text" name="FirstName" value="<?php echo $_SESSION['FirstName'] ?>" </td>
</tr>
<tr>
<td>Last Name:</td><td><input type="text" name="LastName" value="<?php echo $_SESSION['LastName'] ?>" </td>
</tr>
<tr>
<td>Profile Picture:</td><td><input type="file" name="ProfilePicture" id="profilePicture" </td>
</tr>
<tr>
<td><input type="Button" Class="Button" value="Cancel" id="CancelPass1" /></td>
<td><input type="submit" name="SaveProfile" value="Save" id="Save"  class="Button"  /></td>
</tr>
</table>
</div>
<div <?php if($action == "updProfile") echo "style='display: none;'";?>>
<table>
<tr><td>Current Password: </td><td><input type="Password" name="CurrentPwrd" id="Password" /></td></tr>
<tr><td>New  Password: </td><td><input type="Password" name="NewPwrd" id="Password" /></td></tr>
<tr><td>Confirm Password:</td><td><input type="Password" name="ReNewPwrd" id="Password" /></td></tr>
<tr><td colspan=2 style="text-align: center; color:red"><lable><?php echo $Error ?></lable></td></tr>
<tr><td><input type="Button" Class="Button" value="Cancel" id="CancelPass2" /></td>
<td><input type="submit" name="SavePwrd" Class="Button" value="Save" id="SavePass" /></td></tr>
</table>

</div>
</form>
</body>
<script>
$('#CancelPass1').click(function() {
  location.href = 'Profile.php';
});
$('#CancelPass2').click(function() {
  location.href = 'Profile.php';
});
</script>

</html>

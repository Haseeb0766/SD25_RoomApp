use mysql;
go
drop database if exists dbRoomManagement;
go
create database dbRoomManagement;
go
use dbRoomManagement;
go

-- CREATE ALL TABLES

create table tbCampus (
    CampusID int auto_increment primary key,
    CampusName varchar(100),
    StreetAddress varchar(500),
    City varchar(100),
    Province varchar(100),
    PostalCode varchar(20),
    Description varchar(10000)
);
go

create Table tbCampusFloors (
    FloorID int auto_increment primary key,
    FloorNumber varchar(50),
    CampusID int,
    foreign key (CampusID) references tbCampus(CampusID),
    Description varchar(10000)
);
go

create table tbUser (
    Email varchar(100) primary key,
    FirstName varchar(50),
    LastName varchar(50),
    Position varchar(50),
    UserType varchar(50),
    CampusID int,
    foreign key (CampusID) references tbCampus (CampusID),
    Password varchar(100),
    ProfilePicture varchar(1000),
    Description varchar(10000)
);
go

create table tbIntake (
    IntakeID varchar(50) primary key,
    StartDate date,
    EndDate date,
    StartTime time,
    EndTime time,
    InstructorEmail varchar(100),
    foreign key (InstructorEmail) references tbUser(Email),
    NumOfStudents int,
    Description varchar(10000)
);
go

create table tbRoom (
    RoomName varchar(100) primary key,
    RoomNumber varchar(50),     
    CampusID int,
    foreign key (CampusID) references tbCampus(CampusID),
    FloorID int,
    foreign key (FloorID) references tbCampusFloors(FloorID),
    Capacity int,
    MaximumCapacity int, -- this new column needs to be added to the procs
    Status varchar(50), -- Available or Unavailable
    Description varchar(10000)
);
go

create table tbRoomSchedule (
    ID int auto_increment primary key,
    RoomName varchar(100),
    foreign key (RoomName) references tbRoom(RoomName),
    IntakeID varchar(50),
    foreign key (IntakeID) references tbIntake(IntakeID),
    StartDate date,
    EndDate date,
    StartTime time,
    EndTime time,
    Description varchar(10000)
);
go

create table tbAsset (
    AssetID int auto_increment primary key,
    AssetName varchar(100),
    Description varchar(10000)
);
go

create table tbAssetInStock (
    ID int auto_increment primary key,
    AssetID int,
    foreign key (AssetID) references tbAsset(AssetID),
    Quantity int,
    Description varchar(10000)
);
go

create table tbAssetInRoom (
    ID int auto_increment primary key,
    RoomName varchar(100),
    foreign key (RoomName) references tbRoom(RoomName),
    AssetID int,
    foreign key (AssetID) references tbAsset(AssetID),
    Quantity int,
    Description varchar(10000)
);
go

create table tbSupply (
    SupplyID int auto_increment primary key,
    SupplyName varchar(100),
    Description varchar(10000)
);
go

create table tbSupplyInStock (
    ID int auto_increment primary key,
    SupplyID int,
    foreign key (SupplyID) references tbSupply(SupplyID),
    Quantity int,
    Description varchar(10000)
);
go

create table tbSupplyInRoom (
    ID int auto_increment primary key,
    RoomName varchar(100),
    foreign key (RoomName) references tbRoom(RoomName),
    SupplyID int,
    foreign key (SupplyID) references tbSupply(SupplyID),
    Quantity int,
    Description varchar(10000)
);
go

create table tbRequestType (    
    RequestType varchar(100) primary key,
    Description varchar(10000)
);
go

create table tbRequest (
    RequestID int auto_increment primary key,   
    RoomName varchar(100),
    foreign key (RoomName) references tbRoom(RoomName),
    RequestBy varchar(100),
    foreign key (RequestBy) references tbUser(Email),    
    IntakeID varchar(50),
    foreign key (IntakeID) references tbIntake(IntakeID), 
    RequestType varchar(100), -- request types include 'Room', 'Asset', 'Supply'   
    StartDate date,
    EndDate date,
    StartTime time,
    EndTime time,
    RequestDate date,
    ResponseDate date,
    ResponseBy varchar(100),
    foreign key (ResponseBy) references tbUser(Email),
    Status varchar(50), -- Supplied, Approved, Pending, Cancelled, Rejected
    Description varchar(10000)
);
go

create table tbRequestDetail (    
    RequestDetailID int auto_increment primary key,
    RequestID int,
    foreign key (RequestID) references tbRequest(RequestID),
    RequestType varchar(100), -- request types include 'Room', 'Asset', 'Supply'
    foreign key (RequestType) references tbRequestType(RequestType),
    AssetID int,
    foreign key (AssetID) references tbAsset(AssetID),
    AssetQuantity int,
    SupplyID int,
    foreign key (SupplyID) references tbSupply(SupplyID),
    SupplyQuantity int,
    RoomQuantity int,
    StudentNumber int
);
go

create table tbRoomAssetInventory 
(
    ID int auto_increment primary key,
    AssetID int,
    foreign key (AssetID) references tbAsset(AssetID),
    Quantity int
);


-- CREATE ALL PROCEDURES

DELIMITER //
create procedure test (
    IN _val1 int,
    IN _val2 varchar(50),
    IN _val3 varchar(10)
)
begin
    select 'this is just a test' as Result;
    select _val1 as Value1;
    select _val2 as Value2;
    select _val3 as Value3;
end //

create procedure spRequest(
    IN _RequestID int,   
    IN _RoomName varchar(50),   
    IN _RequestBy varchar(100),    
    IN _IntakeID varchar(50), 
    IN _RequestType varchar(100),      
    IN _StartDate date,
    IN _EndDate date,
    IN _StartTime time,
    IN _EndTime time,
    IN _RequestDate date,
    IN _ResponseDate date,
    IN _ResponseBy varchar(100),    
    IN _Status varchar(50), -- Supplied, Approved, Pending, Cancelled, Rejected
    IN _Description varchar(10000),
    IN _action varchar(50) -- valid inputs include 'c', 'r', 'u', 'd', 'requestResponse'
)
begin
    if _action = 'c'
    then
        insert into tbRequest (RoomName, RequestBy, IntakeID, RequestType, StartDate, StartTime, EndTime, EndDate, RequestDate, Status) values
                              (_RoomName, _RequestBy, _IntakeID, _RequestType, _StartDate, _StartTime, _EndTime, _EndDate, _RequestDate, _Status);
        select 'Request ID created' as Result, LAST_INSERT_ID() as RequestID;
    elseif _action = 'r'
    then
        select RequestID, tbRequest.RoomName, RoomNumber, IntakeID, RequestType, RequestBy, FirstName, LastName, StartDate, EndDate, StartTime, EndTime, RequestDate, ResponseDate, ResponseBy, tbRequest.Status, tbRequest.Description
            from tbRequest left join tbRoom on tbRequest.RoomName = tbRoom.RoomName
            left join tbUser on tbRequest.RequestBy = tbUser.Email;      
    elseif _action = 'readByRequest'
    then
        select RequestID, tbRequest.RoomName, RoomNumber, IntakeID, RequestType, RequestBy, FirstName, LastName, StartDate, EndDate, StartTime, EndTime, RequestDate, ResponseDate, ResponseBy, tbRequest.Status, tbRequest.Description
            from tbRequest left join tbRoom on tbRequest.RoomName = tbRoom.RoomName
            left join tbUser on tbRequest.RequestBy = tbUser.Email      
            where RequestID = _RequestID;   
            elseif _action = 'MyReq'
    then
        select RequestID, tbRequest.RoomName, RoomNumber, IntakeID, RequestType, RequestBy, FirstName, LastName, StartDate, EndDate, StartTime, EndTime, RequestDate, ResponseDate, ResponseBy, tbRequest.Status, tbRequest.Description
        from tbRequest inner join tbRoom on tbRequest.RoomName = tbRoom.RoomName
        inner join tbUser on tbRequest.RequestBy = tbUser.Email
where RequestBy = _RequestBy;         
    elseif _action = 'u'
    then    
        update tbRequest set RoomName = IFNULL(_RoomName, RoomName),
							 RequestBy = IFNULL(_RequestBy, RequestBy),
							 IntakeID = IFNULL(_IntakeID, IntakeID),
							 StartDate = IFNULL(_StartDate, StartDate),
							 EndDate = IFNULL(_EndDate, EndDate),
							 StartTime = IFNULL(_StartTime, StartTime),
							 EndTime = IFNULL(_EndTime, EndTime),
                             RequestDate = IFNULL(_RequestDate, RequestDate),
                             ResponseDate = IFNULL(_ResponseDate, ResponseDate),
                             ResponseBy = IFNULL(_ResponseBy, ResponseBy),
                             Status = IFNULL(_Status, Status),
                             Description = IFNULL(_Description, Description)
					   where RequestID = _RequestID;
		  select 'Update successfull' as Result;
    elseif _action = 'd'
    then
        delete from tbRequest where RequestID = _RequestID;
    elseif _action = 'requestResponse'
    then
        update tbRequest set ResponseDate = IFNULL(_ResponseDate, ResponseDate),
                             ResponseBy = IFNULL(_ResponseBy, ResponseBy),
                             Status = IFNULL(_Status, Status),
                             Description = IFNULL(_Description, Description)
					   where RequestID = _RequestID;
		  select 'Response successfull' as Result;
    end if;
end //

create procedure spRequestDetail (
    IN _RequestDetailID int,
    IN _RequestID int,    
    IN _RequestType varchar(100), -- request types include 'Room', 'Asset', 'Supply'    
    IN _AssetID int,    
    IN _AssetQuantity int,
    IN _SupplyID int,    
    IN _SupplyQuantity int,
    IN _RoomQuantity int,
    IN _StudentNumber int,
    IN _action varchar(50) -- valid inputs include 'c', 'r', 'u', 'd'
)
begin
    if _action = 'c'
    then
        insert into tbRequestDetail (RequestID, RequestType, AssetID, AssetQuantity, SupplyID, SupplyQuantity, RoomQuantity,StudentNumber) values
                                    (_RequestID, _RequestType, _AssetID, _AssetQuantity, _SupplyID, _SupplyQuantity, _RoomQuantity,_StudentNumber);
        select 'Request Details successfully inserted' as Result;
    elseif _action = 'r'
    then        
        select RequestType, tbRequestDetail.AssetID, AssetName, AssetQuantity, tbRequestDetail.SupplyID, SupplyName, SupplyQuantity, RoomQuantity ,StudentNumber
            from tbRequestDetail left join tbAsset on tbRequestDetail.AssetID = tbAsset.AssetID
            left join tbSupply on tbRequestDetail.SupplyID = tbSupply.SupplyID
            where RequestID = _RequestID;        
    elseif _action = 'u'
    then
        update tbRequestDetail set RequestID = IFNULL(_RequestID, RequestID),
                                   RequestType = IFNULL(_RequestType, RequestType),
                                   AssetID = IFNULL(_AssetID, AssetID),
                                   AssetQuantity = IFNULL(_AssetQuantity, AssetQuantity),
                                   SupplyID = IFNULL(_SupplyID, SupplyID),
                                   SupplyQuantity = IFNULL(_SupplyQuantity, SupplyQuantity),
                                   RoomQuantity = IFNULL(_RoomQuantity, RoomQuantity),
                                   StudentNumber = IFNULL(_StudentNumber,StudentNumber)
					         where RequestDetailID = _RequestDetailID;
    elseif _action = 'd'
    then
        delete from tbRequestDetail where RequestDetailID = _RequestDetailID;
    end if;
end //

create procedure spUser(
	IN _Email varchar(100),
	IN _FirstName varchar(50),
	IN _LastName varchar(50),
	IN _Position varchar(50),
	IN _CampusID int,
	IN _Description varchar(10000),
	IN _Password varchar(100),
    IN _ProfilePicture varchar (1000),
	IN _UserType varchar(50),
	IN _action varchar(50) -- valid inputs include 'login', 'signup', 'r', 'u', 'd'
)
begin
	if _action = 'login'
	then
		if (exists (select * from tbUser where Email = _Email and Password = _Password))
        then
			select *, 'Login successfull' as LoginResult from tbUser
			where Email = _Email and Password = _Password;
		else
			select 'Login failed' as LoginResult;
        end if;

    elseif _action = 'signup'
    then
        if (exists (select * from tbUser where Email = _Email)) -- check if email already exists
        then
            select 'Email already exists' as SignupResult;
        else
            -- provided email does not exist, so it will proceed by creating the user
            insert into tbUser (Email, Password, FirstName, LastName, Position, CampusID, UserType, ProfilePicture, Description) values
			               	   (_Email, _Password, _FirstName, _LastName, _Position, _CampusID, _UserType, _ProfilePicture, _Description);
            select 'Signup successfull' as SignupResult;
        end if;
    elseif _action = 'r'
    then
		select *, CampusName from tbUser inner join tbCampus
		on tbUser.CampusID = tbCampus.CampusID
		where Email = _Email;
    elseif _action = 'readAll'
    then
		select *, CampusName from tbUser inner join tbCampus
		on tbUser.CampusID = tbCampus.CampusID;		
	elseif _action = 'u'
	then
	      update tbUser set FirstName = IFNULL(_FirstName, FirstName),
							LastName = IFNULL(_LastName, LastName),							
							CampusID = IFNULL(_CampusID, CampusID),
                            ProfilePicture = IFNULL(_ProfilePicture,ProfilePicture),
							Description = IFNULL(_Description, Description)						
					  where Email = _Email;
		  select 'Update successfull' as Result;
	elseif _action = 'd'
    then
    update tbIntake set InstructorEmail = NULL where InstructorEmail = _Email;
    update tbRequest set RequestBy = NULL where RequestBy  =_Email;
    update tbRequest set ResponseBy = NULL where ResponseBy  =_Email;        
    delete from tbUser where Email = _Email;
    select 'User successfully deleted' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //

create procedure spChangePassword(
    IN _Email varchar(100),
    IN _OldPassword varchar(100),
    IN _NewPassword varchar(100)
)
begin
    if (exists (select * from tbUser where Email = _Email and Password = _OldPassword))
        then
            update tbUser set Password = _NewPassword where Email = _Email;
            select 'Password successfully changed' as Result;
        else 
            select 'Wrong password' as Result;
        end if;
end //

create procedure spCampus(
    IN _CampusID int,
    IN _CampusName varchar(100),
    IN _City varchar(100),
    IN _Province varchar(100),
    IN _PostalCode varchar(20),
    IN _Description varchar(10000),
    IN _action varchar(50) -- valid inputs include 'c', 'readCampus', 'readAllCampuses', 'u', 'd'
)
begin
	if _action = 'c'
    then
        if (exists (select * from tbCampus where CampusName = _CampusName or PostalCode = _PostalCode)) -- check if Campus already exists
        then
            select 'Campus already exists' as CampusResult;
        else
            -- New Campus does not exist, so it will proceed by creating the Campus
            insert into tbCampus (CampusName, City, Province, PostalCode, Description) values
			               	   (_CampusName, _City, _Province, _PostalCode, _Description);
            select 'Campus successfully created' as CampusResult;
        end if;
    elseif _action = 'readCampus'
    then
		select * from tbCampus where CampusID = _CampusID;
    elseif _action = 'readAllCampuses'
    then
		select * from tbCampus;
	elseif _action = 'u'
	then
	      update tbCampus set CampusName = IFNULL(_CampusName, CampusName),
							City = IFNULL(_City, City),
							Province = IFNULL(_Province, Province),
							PostalCode = IFNULL(_PostalCode, PostalCode),
							Description = IFNULL(_Description, Description)
					  where CampusID = _CampusID;
		  select 'Update successfull' as UpdateResult;
	elseif _action = 'd'
    then
        delete from tbCampus where CampusID = _CampusID;
	    select 'Campus deleted successfully' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //


create procedure spAsset(
    IN _AssetID int,
    IN _AssetName varchar(100),
    IN _RoomName varchar(50),
    IN _Quantity int,
    IN _Description varchar(10000),
    IN _action varchar(50) -- valid inputs include 'c', 'readAsset', 'readAllAssets', 'u', 'd'
)
begin
	if _action = 'c'
    then
        if (exists (select * from tbAsset where AssetName = _AssetName)) -- check if Asset already exists
        then
            select 'Asset already exists' as AssetResult;
        else
            -- New Asset does not exist, so it will proceed by creating the Asset
            insert into tbAsset (AssetName, Description) values
			               	   (_AssetName, _Description);
            select 'Asset successfully created' as AssetResult;
        end if;
    elseif _action = 'readAsset'
    then
		select * from tbAsset where AssetID = _AssetID;
    elseif _action = 'readAssetQuantity'
    then
		select tbAssetInStock.AssetID as AssetID, tbAsset.AssetName, tbAssetInStock.Quantity as QtyInStock, tbRoomAssetInventory.Quantity as QtyInRoom  from tbAssetInStock
        inner join tbAsset on tbAsset.AssetID = tbAssetInStock.AssetID 
        inner join tbRoomAssetInventory on tbAsset.AssetID = tbRoomAssetInventory.AssetID
        where tbAsset.AssetID = _AssetID;    
    elseif _action = 'readAllAssets'
    then
		select * from tbAsset;
    elseif _action = 'readAllAssetQuantity'
    then
		select tbAssetInStock.AssetID as AssetID, tbAsset.AssetName, tbAssetInStock.Quantity as QtyInStock, tbRoomAssetInventory.Quantity as QtyInRoom  from tbAssetInStock
        inner join tbAsset on tbAsset.AssetID = tbAssetInStock.AssetID 
        inner join tbRoomAssetInventory on tbAsset.AssetID = tbRoomAssetInventory.AssetID;    
    elseif _action = 'readAllRoomsAssetQuantity'
    then
        select tbAssetInRoom.RoomName, tbRoom.RoomNumber, tbAssetInRoom.AssetID, tbAsset.AssetName, tbAssetInRoom.Quantity
        from tbAssetInRoom inner join tbRoom on tbAssetInRoom.RoomName = tbRoom.RoomName
        inner join tbAsset on tbAssetInRoom.AssetID = tbAsset.AssetID;    
    elseif _action = 'readRoomAssetQuantity'
    then
        select tbAssetInRoom.RoomName, tbRoom.RoomNumber, tbAssetInRoom.AssetID, tbAsset.AssetName, tbAssetInRoom.Quantity
        from tbRoom inner join tbAssetInRoom on tbAssetInRoom.RoomName = tbRoom.RoomName
        inner join tbAsset on tbAssetInRoom.AssetID = tbAsset.AssetID  
        where tbAssetInRoom.RoomName = _RoomName;                  
	elseif _action = 'u'
	then
	      update tbAsset set AssetName = IFNULL(_AssetName, AssetName),
							 Description = IFNULL(_Description, Description)
					   where AssetID = _AssetID;
		  select 'Update successfull' as UpdateResult;
    elseif _action = 'UpdateAssetInStock'
    then
        update tbAssetInStock set Quantity = IFNULL(_Quantity, Quantity) where AssetID = _AssetID;
        select 'Update successfull' as UpdateResult;
    elseif _action = 'UpdateAssetInRoom'
	then   
        SET @QuantityInStock  = (select SUM(Quantity) from tbAssetInStock where AssetID = _AssetID); 
        if exists(select * from tbAssetInRoom where AssetID = _AssetID and RoomName = _RoomName)
        then   
            SET @QuantityInRoom  = (select SUM(Quantity) from tbAssetInRoom where AssetID = _AssetID and RoomName = _RoomName);                  
            SET @CurrentStockQTY =  @QuantityInRoom + @QuantityInStock;                       
            if (_Quantity <= @CurrentStockQTY)
            then
                update tbAssetInStock set Quantity = (@CurrentStockQTY - _Quantity) where AssetID = _AssetID;
                update tbAssetInRoom set Quantity = IFNULL(_Quantity, Quantity),
							             Description = IFNULL(_Description, Description)
					                     where AssetID = _AssetID and RoomName = _RoomName; 
                select 'Update successfull' as UpdateResult;
            else
                select 'Asset quantity out of stock' as UpdateResult;  
            end if;                    
        else
            if (_Quantity <= @QuantityInStock)
            then
                insert into tbAssetInRoom (RoomName, AssetID, Quantity) values (_RoomName, _AssetID, _Quantity);
                select 'Update successfull' as UpdateResult; 
            else
                select 'Asset quantity out of stock' as UpdateResult;
            end if;
        end if;   
        SET @QuantityUpdated  = (select SUM(Quantity) from tbAssetInRoom where AssetID = _AssetID);        
        update tbRoomAssetInventory set Quantity = @QuantityUpdated where AssetID = _AssetID;	    
	elseif _action = 'd'
    then
        delete from tbAsset where AssetID = _AssetID;
	    select 'Asset deleted successfully' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //

create procedure spRoom(
    IN _RoomName varchar(100),
    IN _RoomNumber varchar(50),     
    IN _CampusID int,    
    IN _FloorID int,    
    IN _Capacity int,
    IN _MaximumCapacity int, 
    IN _Status varchar(50), 
    IN _Description varchar(10000),
    IN _action varchar(50) -- valid inputs include 'c', 'readRoom', 'readAllRooms', 'u', 'd'
)
begin
    if _action = 'c'
    then
        if (exists (select * from tbRoom where RoomName = _RoomName)) -- check if Room already exists
        then
            select 'Room already exists' as RoomResult;
        else
            -- New Room does not exist, so it will proceed by creating the Room
            insert into tbRoom (RoomName, RoomNumber, CampusID, FloorID, Capacity, MaximumCapacity, Status, Description) values
			                   (_RoomName, _RoomNumber, _CampusID, _FloorID, _Capacity, _MaximumCapacity, _Status, _Description);
            select 'Room successfully created' as CampusResult;
        end if;
    elseif _action = 'readRoom'
    then
		select * from tbRoom where RoomName = _RoomName;
    elseif _action = 'readFloor'
    then
		select * from tbRoom where FloorID = _FloorID;
    elseif _action = 'readAllRooms'
    then
		select * from tbRoom;
	elseif _action = 'u'
	then
	    update tbRoom set RoomNumber = IFNULL(_RoomNumber, RoomNumber),
						  CampusID = IFNULL(_CampusID, CampusID),
						  FloorID = IFNULL(_FloorID, FloorID),
						  Capacity = IFNULL(_Capacity, Capacity),
                          MaximumCapacity = IFNULL(_MaximumCapacity, MaximumCapacity),
                          Status = IFNULL(_Status, Status),
                          Description = IFNULL(_Description, Description)
					where RoomName = _RoomName;
		select 'Update successfull' as UpdateResult;
	elseif _action = 'd'
    then
        delete from tbRoom where RoomName = _RoomName;
	    select 'Room deleted successfully' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //

create procedure spUpdateRoomDetails (
    IN _RoomName varchar(100),
    IN _RoomNumber varchar(50),     
    IN _CampusID int,    
    IN _FloorID int,    
    IN _MaximumCapacity int, 
    IN _ChairQuantity int,
    IN _TableQuantity int,
    IN _PowerCordQuantity int,
    IN _ProjectorQuantity int,
    IN _MonitorQuantity int,
    IN _RoomComputerQuantity int
)
begin 
    update tbRoom set RoomNumber = IFNULL(_RoomNumber, RoomNumber),
						  CampusID = IFNULL(_CampusID, CampusID),
						  FloorID = IFNULL(_FloorID, FloorID),
                          MaximumCapacity = IFNULL(_MaximumCapacity, MaximumCapacity)
					where RoomName = _RoomName;
        update tbAssetInRoom set Quantity = IFNULL(_ChairQuantity, Quantity) where AssetID = 1;
        update tbAssetInRoom set Quantity = IFNULL(_TableQuantity, Quantity) where AssetID = 2;
        update tbAssetInRoom set Quantity = IFNULL(_PowerCordQuantity, Quantity) where AssetID = 3;
        update tbAssetInRoom set Quantity = IFNULL(_ProjectorQuantity, Quantity) where AssetID = 4;
        update tbAssetInRoom set Quantity = IFNULL(_MonitorQuantity, Quantity) where AssetID = 5;
        update tbAssetInRoom set Quantity = IFNULL(_RoomComputerQuantity, Quantity) where AssetID = 6;
		select 'Update successfull' as UpdateResult;
end//

create procedure spSupply(
    IN _SupplyID int,
    IN _SupplyName varchar(100),
    IN _Description varchar(10000),
    IN _Quantity int,
    IN _action varchar(50) -- valid inputs include 'c', 'readSupply', 'readAllSupplies', 'u', 'd'
)
begin
	if _action = 'c'
    then
        if (exists (select * from tbSupply where SupplyName = _SupplyName)) -- check if Supply already exists
        then
            select 'Supply already exists' as SupplyResult;
        else
            -- New Supply does not exist, so it will proceed by creating the Supply
            insert into tbSupply (SupplyName, Description) values
			               	   (_SupplyName, _Description);
            SET @ID = (select SupplyID from tbSupply where SupplyName  = _SupplyName);
            insert into tbSupplyInStock (SupplyID ,Quantity) values
                                        (@ID,_Quantity);
            select 'Supply successfully created' as SupplyResult;
        end if;
    elseif _action = 'readSupply'
    then
		select * from tbSupply where SupplyID = _SupplyID;
    elseif _action = 'readAllSupplies'
    then
		select tbSupply.SupplyID, tbSupply.SupplyName, tbSupply.Description, tbSupplyInStock.Quantity from tbSupply
        left outer join tbSupplyInStock on tbSupply.SupplyID = tbSupplyInStock.SupplyID;
	elseif _action = 'u'
	then
	      update tbSupply set SupplyName = IFNULL(_SupplyName, SupplyName),
							 Description = IFNULL(_Description, Description)
					   where SupplyID = _SupplyID;
          update tbSupplyInStock set Quantity = IFNULL(_Quantity, Quantity)							 
					   where SupplyID = _SupplyID;
		  select 'Update successfull' as UpdateResult;
	elseif _action = 'd'
    then
        delete from tbSupply where SupplyID = _SupplyID;

	    select 'Supply deleted successfully' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //

create procedure spAssetInRoom(
    IN _ID int,
    IN _RoomName varchar(100),    
    IN _AssetID int,    
    IN _Quantity int,
    IN _Description varchar(10000),    
    IN _action varchar(50) -- valid inputs include 'c', 'readAsset', 'readAllAssetsInRoom', 'u', 'deleteAssetInRoom', 'deleteAllAssetsInRoom'
)
begin
	if _action = 'c'
    then
        if (exists (select * from tbAssetInRoom where RoomName = _RoomName and AssetID = _AssetID)) -- check if that Asset already exists in the room
        then
            select 'Asset already exists' as AssetResult;
        else
            -- The Asset does not exist in the room, so it will proceed by inserting the Asset
            insert into tbAssetInRoom (RoomName, AssetID, Quantity, Description) values
			               	          (_RoomName, _AssetID, _Quantity, _Description);
            select 'Asset successfully inserted' as AssetResult;
        end if;
    elseif _action = 'readAsset'
    then
		select * from tbAssetInRoom where RoomName = _RoomName and AssetID = _AssetID;
    elseif _action = 'readAllAssetsInRoom'
    then
		select tbAssetInRoom.RoomName,tbAssetInRoom.AssetID,tbAssetInRoom.Quantity,tbAssetInRoom.Description, tbAsset.AssetName, tbRoom.RoomNumber, tbRoom.FloorID, tbRoom.MaximumCapacity,tbRoom.CampusID,tbRoom.Description, tbCampus.CampusName from tbAssetInRoom 
        inner join tbAsset on tbAssetInRoom.AssetID = tbAsset.AssetID
        inner join tbRoom on tbAssetInRoom.RoomName = tbRoom.RoomName 
        inner join tbCampus on tbRoom.CampusID = tbCampus.CampusID
        where tbAssetInRoom.RoomName = _RoomName;
	elseif _action = 'u'
	then
	      update tbAssetInRoom set RoomName = IFNULL(_RoomName, RoomName),
							 AssetID = IFNULL(_AssetID, AssetID),
                             Quantity = IFNULL(_Quantity, Quantity),
                             Description = IFNULL(_Description, Description)
					   where ID = _ID;
		  select 'Update successfull' as UpdateResult;
	elseif _action = 'deleteAssetInRoom'
    then
        delete from tbAssetInRoom where RoomName = _RoomName and AssetID = _AssetID;
	    select 'Asset deleted successfully' as DeleteResult;
    elseif _action = 'deleteAllAssetsInRoom'
    then
        delete from tbAssetInRoom where RoomName = _RoomName;
	    select 'Assets deleted successfully' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //

create procedure spIntake(
    _IntakeID varchar(50),
    _StartDate date,
    _EndDate date,
    _StartTime time,
    _EndTime time,
    _InstructorEmail varchar(100),
    _NumOfStudents int,
    _Description varchar(10000),
    _action varchar(50) -- valid inputs include 'c', 'readIntake', 'readAllIntakes', 'u', 'd'
)
begin
    if _action = 'c'
    then
        if (exists (select * from tbIntake where IntakeID = _IntakeID)) -- check if Intake already exists
        then
            select 'Intake already exists' as IntakeResult;
        else
            -- New Intake does not exist, so it will proceed by creating the Intake
            insert into tbIntake (IntakeID, StartDate, EndDate, StartTime, EndTime, InstructorEmail, NumOfStudents, Description) values
			               	     (_IntakeID, _StartDate, _EndDate, _StartTime, _EndTime, _InstructorEmail, _NumOfStudents, _Description);
            select 'Intake successfully created' as IntakeResult;
        end if;
    elseif _action = 'readIntake'
    then
		select * from tbIntake where IntakeID = _IntakeID;
    elseif _action = 'readAllIntakes'
    then
		select * from tbIntake;
	elseif _action = 'u'
	then
	      update tbIntake set StartDate = IFNULL(_StartDate, StartDate),
                              EndDate = IFNULL(_EndDate, EndDate),
                              StartTime = IFNULL(_StartTime, StartTime),
                              EndTime = IFNULL(_EndTime, EndTime),
                              InstructorEmail = IFNULL(_InstructorEmail, InstructorEmail),
                              NumOfStudents = IFNULL(_NumOfStudents, NumOfStudents),
                              Description = IFNULL(_Description, Description)
					   where IntakeID = _IntakeID;
		  select 'Update successfull' as UpdateResult;
	elseif _action = 'd'
    then
        delete from tbIntake where IntakeID = _IntakeID;
	    select 'Intake deleted successfully' as DeleteResult;
    else
        select 'Wrong action code' as Result;
    end if;
end //


DELIMITER ;



insert into tbCampus (CampusName, StreetAddress, City, Province, PostalCode, Description) values 
                     ('Notre Dame Campus','265 Notre Dame Avenue','Winnipeg','Manitoba','R3B 1N9','Main Campus with newly renovated labs'), 
                     ('Main Street Campus','433 Main Street', 'Winnipeg', 'Manitoba','R3B 1B3','Second Campus home to Massage Therapy classrooms and business programs' );
                          select * from tbCampus;

call spUser('doug.jackson@robertsoncollege.net', 'Dawit', 'Abraham', 'Instructor', '1', 'Nothing to be described', 'password', '123.jpeg', 'Admnistrator', 'signup');

insert into tbUser (Email, FirstName,LastName,UserType,CampusID,Password, Description) values
                    ('dawit114@yahoo.com', 'Doug','Jackson', 'Instructor',1,'password1','Male'),
                    ('carey.wolfe@robertsoncollege.net', 'Carey','Wolfe', 'Instructor',1,'password2','Female'),
                    ('al.skipper@robertsoncollege.net', 'Al','Skipper', 'Instructor',1,'password3','Microsoft Certified System Engineer'),
                    ('christa.mckegney@robertsoncollege.net', 'Christa','McKegney', 'Instructor',2,'password4','Massage Therapy Program Coordinator'),
                    ('emah.christiansen@robertsoncollege.net', 'Emah','Christiansen', 'Instructor',2,'password5','Expertise in orhopedic pathologies'),
                    ('facilitymanager@robertsoncollege.com', 'Doug','Jackson', 'Admnistrator',1,'password5','Facility Manager'),
                    ('rkroeker@robertsoncollege.com', 'Rita','Kroeker', 'Admnistrator',1,'password6','Education Manager');
    
insert into tbIntake (IntakeID, StartDate, EndDate, StartTime, EndTime, InstructorEmail, NumOfStudents, Description) values 
                    ("AMT15", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Advanced Massage Therapy"),
                    ("CSW21", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Community Support Worker"),
                    ("HCA45", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Health Care Aid"),
                    ("HCAC22", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Health Care Aid Challenge"),
                    ("HUC09", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Medical Office Assistant"),
                    ("MTERM07", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Medical Terminology"),
                    ("NA42", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Nursing Assistant"),
                    ("PA16", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Pharmacy Assistant"),
                    ("PT27", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Pharmacy Technician"),
                    ("NPTSD14", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"National Pharmacy Technician Bridging education Program"),
                    ("MTCE21", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Massage Therapy Continuing Education and Workshops"),
                    ("APA32", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Accounting and Payroll Administrator"),
                    ("AA19", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Accounting Assistantr"),
                    ("AS21", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Accounting Specialist"),
                    ("AP23", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Administrative Professional"),
                    ("APB19", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Administrative Professional Bookkeeper"),
                    ("BAM30", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Business Administration Management"),
                    ("BA42", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Business Administration"),
                    ("DM24", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Digital Marketing"),
                    ("LA04", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Legal Assistant"),
                    ("LSCH09", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Logistics and Supply Chain Management"),
                    ("OGA08", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Oil and Gas Administrator"),
                    ("PM22", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Project Management"),
                    ("SBM28", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Small Business Management"),
                    ("TC41", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Travel Counsellor"),
                    ("VOA18", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Veterinary Office Assistant"),
                    ("VOATA07", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Veterinary Office and Technical Assistant"),
                    ("NA10", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Network Administrator"),
                    ("NST15", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Network Security Technician"),
                    ("SD25", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Software and Database Developer"),
                    ("MA17", "2016-10-03", "2017-09-06", "13:00", "18:00", "doug.jackson@robertsoncollege.net",16,"Mobile Applications");
               

insert into tbAsset (AssetName, Description) values
    ("Chair", "No comment"),
    ("Table", "No comment"),
    ("Power Cord", "No comment"),
    ("Projector","No comment"),
    ("Monitor","No comment"),
    ("Room Computer","Laptop or Desktop");

insert into tbAssetInStock (AssetID,Quantity) values
    (1,6),(2,50),(3,10),(4,20),(5,30),(6,40);

insert into tbSupply(SupplyName, Description) values
    ("Lysol", "Not for whiteboards"),
    ("Vinegar Water", "Fine cleaner for whiteboards"),
    ("Paper Towel", "Big Roll"),
    ("Windex","Cleaner with Ammonia D");

insert into tbSupplyInStock (SupplyID,Quantity,Description) values
    ('1','10', 'Each box has 4x4 litres'),
    ('2','5','Each box has 20 pieces');
 
insert into tbRequestType (RequestType,Description) values
    ('Room','Big enough for 16 students'),
    ('Asset','Chairs and tables only'),
    ('Supply','Everything is needed');

insert into tbCampusFloors (FloorNumber, CampusID) values
                             ('Lower Level',1),
                             ('Floor 1',1),
                             ('Floor 2',1),
                             ('Floor 3',1),
                             ('Floor 4',1),
                             ('Floor 5',1),
                             ('Floor 3',2),
                             ('Floor 13',2);

insert into tbRoom(RoomNumber, RoomName, CampusID, FloorID, Capacity, MaximumCapacity, Status, Description) values
    ("L02","Quebec",1,1,16,18,"Available","No comment"),
    ("L03","New Brunswick",1,1,00,00,"Available","No comment"),
    ("L04","Prince Edward Island",1,1,16,20,"Available","No comment"),
    ("L05","Nova Scotia",1,1,00,00,"Available","No comment"),
    ("L06","Newfoundland",1,1,12,14,"Available","No comment"),
    ("100","Ottawa",1,2,32,42, "Available","No comment"),
    ("101","Ontario",1,1,10,14,"Available", "No comment"),
    ("103","Montreal",1,1,24,27,"Available","No comment"),
    ("203","Niagara",1,3,16,20,"Available","No comment"),
    ("210","Thunder Bay",1,3,16,20,"Available","No comment"),
    ("300","Churchill",1,4,16,18,"Available","No comment"),
    ("301","Dauphin",1,4,18,18,"Available","No comment"),
    ("306","Morden",1,4,20,22,"Available","No comment"),
    ("307","Gimli",1,4,22,24,"Available","No comment"),
    ("401","Lethbridge",1,5,17,23,"Available","No comment"),
    ("402","Edmonton",1,5, 18,22,"Available","No comment"),
    ("403","Calgary",1,5,12,16,"Available","No comment"),
    ("405","Alberta",1,5,18,22,"Available","No comment"),
    ("406","Saskatoon",1,5,12,16,"Available","No comment"),
    ("502","Victoria",1,6,20,23,"Available","No comment"),
    ("503","Tofino",1,6,10,12,"Available","No comment"),
    ("504","British Columbia",1,6,28,30,"Available","No comment"),
    ("506","Banff",1,6,45,50,"Available","No comment"),
    ("300","Kelowna",1,7,22,27,"Available","No comment"),
    ("301","Kamloops",1,7, 32,32,"Available","No comment"),
    ("1301","Yellow",1,8,28,28,"Available","No comment"),
    ("1302","Hay River",1,8,17,23,"Available","No comment"),
    ("1303","Yukon",1,8,28,28,"Available","No comment"),
    ("1304","White House",1,8,16,24,"Available","No comment"),
    ("1305","Nunavut",1,8,16,24,"Available","No comment"),
    ("1306","Dawson",1,8,16,24,"Available","No comment"),
    ("1307","Alaska",1,8,16,24,"Available","No comment");


call test(3, 'X', 'Y');
 insert into tbRoom (RoomName, RoomNumber, CampusID, FloorID, Capacity, MaximumCapacity, Status, Description) values
                    ("Monstreal","100",1,1,"20","30","Booked","This is Monstreal");

insert into tbIntake (IntakeID, StartDate, EndDate, StartTime, EndTime, InstructorEmail, NumOfStudents) values  
                     ("SD26", "2016-10-03", "2017-09-06", "13:00", "18:00", "dawit114@yahoo.com", 16);

insert into tbRoomSchedule (RoomName, IntakeID,StartDate,EndDate,StartTime,EndTime,Description) values
                    ("Edmonton","SD25", "2016-10-03","2017-09-06", "13:00", "18:00","Software and Database Developer 25th Cohort");

insert into tbAssetInRoom (RoomName, AssetID,Quantity,Description) values
    ("Edmonton",1, 18,"Enough"),
    ("Edmonton",2, 17,"Enough"),
    ("Edmonton",3, 0,"Enough"),
    ("Edmonton",4, 16,"Enough"),
    ("Edmonton",5, 15,"Enough"),
    ("Edmonton",6, 14,"Enough"),
    ("Alaska",1, 10,"Enough"),
    ("Alaska",2, 11,"Enough"),
    ("Alaska",3, 12,"Enough"),
    ("Alaska",4, 13,"Enough"),
    ("Alaska",5, 25,"Enough"),
    ("Alaska",6, 0,"Enough");

insert into tbRoomAssetInventory (AssetID,Quantity) values (1,18),(2,0),(3,0),(4,0),(5,0),(6,0);
 
insert into tbSupplyInRoom (RoomName,SupplyID,Quantity,Description) values
    ('Edmonton', 1, '1','To be refilled by end of May 2017');   

insert into tbRequest (RoomName,RequestBy,IntakeID,RequestType,StartDate,EndDate,StartTime,EndTime,RequestDate,ResponseDate,ResponseBy,Status,Description) values
    ("Edmonton","doug.jackson@robertsoncollege.net","SD25", "Room", "2016-10-03", "2017-09-06", "13:00", "18:00","2017-05-25","2017-05-26","facilitymanager@robertsoncollege.com","Approved","No comments");

insert into tbRequestDetail (RequestID,RequestType,AssetID,AssetQuantity,SupplyID,SupplyQuantity,RoomQuantity,StudentNumber) values
("1","Room",1, 1,1,"1",16,16);


call spAssetInRoom(NULL, 'Edmonton',NULL,Null,Null,'readAllAssetsInRoom');

insert into tbRequest (RoomName, RequestBy, IntakeID, RequestType, StartDate, EndDate, StartTime, EndTime, RequestDate, Status) values
                      (NULL, 'dawit114@yahoo.com', 'SD25', 'Room', '2016-10-03', '2017-09-06', '13:00:00', '18:00:00', '2016-10-01', 'Pending');

insert into tbRequestDetail (RequestID, RequestType, RoomQuantity, StudentNumber) values
                            (1, 'Room', 1, 25);


#call spRequest('-1', NULL,'dawit114@yahoo.com', 'SD25', 'Room', '2016-01-01', '2017-01-01', '13:00', '18:00', '2017/06/08', NULL, NULL, 'Pending', 'None', 'c');
#call spRequestDetail('-1', '1', 'Room', NULL, NULL, NULL, NULL, '1', '5', 'c');
#call spRequestDetail('-1', '1', 'Asset', '3', '3', NULL, NULL, NULL, NULL, 'c');
#call spRequestDetail('-1', '1', 'Asset', '4', '1', NULL, NULL, NULL, NULL, 'c');
#call spRequestDetail('-1', '1', 'Asset', '6', '1', NULL, NULL, NULL, NULL, 'c');
<?php 
session_start();
require("SupplyClass.php");

if(isset($_POST["SubmitDEL"])){
    parse_str($_SERVER['QUERY_STRING']);
$SupplyID =  trim($SupplyID);
echo $SupplyID;
 $DBconn = new SupplyClass();
    $DBconn->connect();
    $result = $DBconn->DeleteSupply($SupplyID); 
    $DBconn->close();
  // header('location:Supplies.php');
}
if(isset($_POST["UpdateSupply"])){
  $SupplyName =  $_POST["SupplyName"];
    $Description =  $_POST["Description"];
    $SupplyID =  $_POST["SupplyID"];
     $Quantity =  $_POST["Quantity"];
    $DBconn = new SupplyClass();
    $DBconn->connect();
    $result = $DBconn->UpdateSupply($SupplyID,$SupplyName,$Description,$Quantity); 
    $DBconn->close();
    header('location:Supplies.php');

}
else
if(isset($_POST["InsertSupply"])){{
 $SupplyName =  $_POST["SupplyName"];
 $Description =  $_POST["Description"];
    $Quantity =  $_POST["Quantity"];
    $DBconn = new SupplyClass();
    $DBconn->connect();
    $result = $DBconn->InsertSupply($SupplyName,$Description,$Quantity); 
    $DBconn->close();
    header('location:Supplies.php');
}
}

?>
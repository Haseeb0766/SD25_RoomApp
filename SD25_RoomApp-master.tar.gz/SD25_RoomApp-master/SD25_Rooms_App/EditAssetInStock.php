<?php
include("Master.php");
session_start();
require("InventoryClass.php");
parse_str($_SERVER['QUERY_STRING']);
$action =  trim($action);
if($action == 'UpdateRoom'){
        $RoomName =  trim($RoomName);
}
else{
        $RoomName = "";
}
$ChairQTY =  trim($ChairQTY);
$TableQTY =  trim($TableQTY);
$PowerCordQTY =  trim($PowerCordQTY);
$ProjectorQTY =  trim($ProjectorQTY);
$MonitorQTY =  trim($MonitorQTY);
$RoomComputerQTY =  trim($RoomComputerQTY);
$DBconn = new InventoryClass();
$DBconn->connect();
$DBconn->readAsset($AssetID);
$DBconn->close();
?>
<html>
    <header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
    <form action="Access_Assets.php" method="POST">
    <h2 style="text-align:center" >Edit Asset Quantities</h2>
    <input type="text" id="field0" name="action" value="<?php echo $action ?>" style="visibility: hidden"/>
    <input type="text" id="field0" name="RoomName" value="<?php echo $RoomName ?>" style="visibility: hidden"/>
    <input type="text" id="field1" name="ChairQTY" value="<?php echo $ChairQTY ?>" style="visibility: hidden"/>
    <input type="text" id="field2" name="TableQTY" value="<?php echo $TableQTY ?>" style="visibility: hidden"/>
    <input type="text" id="field3" name="PowerCordQTY" value="<?php echo $PowerCordQTY ?>" style="visibility: hidden"/>
    <input type="text" id="field4" name="ProjectorQTY" value="<?php echo $ProjectorQTY ?>" style="visibility: hidden"/>
    <input type="text" id="field5" name="MonitorQTY" value="<?php echo $MonitorQTY ?>" style="visibility: hidden"/>
    <input type="text" id="field6" name="RoomComputerQTY" value="<?php echo $RoomComputerQTY ?>" style="visibility: hidden"/>
    <table>    
    <tr>
    <td>Asset Name</td>
    <td>
        <select id="filter" name="Assets">
        <option id="Chair">Chair</option>
        <option id="Table" >Table</option>
        <option id="PowerCord" >Power Cord</option>
        <option id="Projector" >Projector</option>
        <option id="Monitor" >Monitor</option>
        <option id="RoomComputer" >Room Computer</option>
        </select>
    </td>
    </tr>        
    <tr>
    <td>
    Asset Quantity
    </td>
    <td>
      <input type="text" name="AssetQuantity" id="QTYfield" />
    </td>
    </tr>
    <tr>
    <td>
    <input type="submit" name="CancelUpdate" value="Cancel"/>
    </td>
    <td>
    <input type="submit" name="SaveUpdate" value="Save"/>
    </td>
    </tr>
    </table>    
    </form>

    <script type="text/javascript">
    $(function() {
    $('#filter').change(function(){
    var option=document.getElementById('filter').value;    
    if(option=="Chair"){        
            document.getElementById('QTYfield').value = document.getElementById('field1').value;
    }
    else if(option=="Table"){        
            document.getElementById('QTYfield').value = document.getElementById('field2').value;
    }
    else if(option=="Power Cord"){        
            document.getElementById('QTYfield').value = document.getElementById('field3').value;
    }
    else if(option=="Projector"){        
            document.getElementById('QTYfield').value = document.getElementById('field4').value;
    }
    else if(option=="Monitor"){        
            document.getElementById('QTYfield').value = document.getElementById('field5').value;
    }
    else if(option=="RoomComputer"){        
            document.getElementById('QTYfield').value = document.getElementById('field6').value;
    }
    });
    });
    </script>
    
</html>
<?php
class RoomsClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}
    function connect (){
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);   
                                              
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }
    function close()
    {
        $this->conn->close();
    }
    function ReadRooms() 
    {
       
           $sql = "call spRoom (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'readAllRooms')";
    
       
        $result = $this->conn->query($sql);
    
 
        if($result->num_rows > 0)
        {            
             $RoomTable = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Room Number</th>
                        <th>Room Name </th>
                        <th>Room Capacity</th>
                        
                      <th></th>
                        
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $RoomTable = $RoomTable . "<tr><td>"  . $row["RoomNumber"] . "</td>" .
                                                     "<td>" . $row["RoomName"] . "</td>" . 
                                                     "<td>" . $row["Capacity"]. "</td>" .                                                    
                                                     "<td><input type='Submit' name='View Details' value='View Detail'" 
                                                     ."formaction='RoomDetails.php?"
                ."RoomName=".$row['RoomName']
                              
             ."'/></td>".
            "</tr>";               
            }            
            $RoomTable = $RoomTable . "</tbody></table></form>";
            echo $RoomTable; 
         
          
        }
    }
        function ReadOneFloor($FloorID) 
    {
       
           $sql = "call spRoom (NULL,NULL,NULL,'" . $FloorID . "',NULL,Null,Null,Null,'readFloor')";
    
        $result = $this->conn->query($sql);
    $Rooms = array(array(),array()) ;
        if($result->num_rows > 0)
        {      
            $i =0;      
            while($row = $result->fetch_assoc()){
                   $Rooms[$i][0]= $row["RoomNumber"];
                   $Rooms[$i][1]= $row["RoomName"];
                   $Rooms[$i][2]= $row["MaximumCapacity"];
                   $i = $i+1;
            }            
            
          
        }
        else{
            echo 'Something is Wrong';
        }
        return $Rooms;
    }
    function Insert($RoomName,$RoomNumber,$CampusID,$FloorID,$Capacity,$MaxCapacity,$Status,$Description)
    {
         $Campus = 0;
        switch($CampusID){
            case 'NortdameCampus': $Campus = 1;
            break;
            case 'MainstCampus': $Campus = 2;
            break;
            default: $CampusID = 0;
            break;
        }
        $Floor = 0;
        switch ($FloorID) {
            case 'Lower Level': $Floor = 1;
                # code...
                break;
                 case 'Floor 1': $Floor = 2;
                 break;
                  case 'Floor 2': $Floor = 3;
                  break;
                 case 'Floor 3': $Floor = 4;
                 break;           
             case 'Floor 4': $Floor = 5;
             break; 
              case 'Floor 5': $Floor = 6;
              break;
     case 'Floor 13': $Floor = 7;
     break;
      case '3rd Floor': $Floor = 8;
            default:
               $Floor = 0;
                break;
        }
   
         $sql = "call spRoom ('" . $RoomName . "','" .$RoomNumber . "','" . $Campus ."','". $Floor . "','" .$Capacity . "','". $MaxCapacity . "','". $Status . "','" . $Description . "','c')";
        $result = $this->conn->query($sql);
        return 'Success';
    }
    function ReadRoomDetails($RoomName){
 $sql = "call spAssetInRoom (NULL,'" . $RoomName . "',NULL, NULL, NULL, 'readAllAssetsInRoom')";
    
        $result = $this->conn->query($sql);
        $RoomDetails = array();
        if($result->num_rows > 0)
        {            
             $RoomTable = "<form action='' method='POST'><table>                
                <tbody>";
                $i = 0;
                $ArrayCount = 5;
            while($row = $result->fetch_assoc()){
                if($i<=0){
                    $RoomTable = $RoomTable . "<tr><td>Room Number</td><td>"  . $row["RoomNumber"] . "</td></tr>" .
                                                     "<tr><td>Room Name</td><td>" . $row["RoomName"] . "</td></tr>" . 
                                                     "<tr><td>Campus</td><td>" . $row["CampusName"]. "</td></tr>" . 
                                                     "<tr><td>Floor #</td><td>" . $row["FloorID"]. "</td></tr>" . 
                                                     "<tr><td>Room Capacity</td><td>" . $row["MaximumCapacity"]. "</td></tr>" ;
                    $RoomTable = $RoomTable .  "<tr><td colspan=2 style='text-align: center; font-weight: bold; font-style: italic'>Assets Details</td></tr>";
                     $RoomDetails[0] = $row["RoomNumber"];
                     $RoomDetails[1] = $row["RoomName"];
                     $RoomDetails[2] = $row["CampusName"];
                     $RoomDetails[3] = $row["FloorID"];
                     $RoomDetails[4] = $row["MaximumCapacity"];
                }
                $i = $i + 1;  
                $AssetName = ''; 
                switch($row["AssetID"]){
                    case '1': $AssetName = 'Chairs';
                        break;
                        case '2': $AssetName = 'Tables';
                        break;
                        case '3': $AssetName = 'Power Cords';
                        break;
                        case '4': $AssetName = 'Projectors';
                        break;
                        case '5': $AssetName = 'Monitors';
                        break;
                        case '6': $AssetName = 'Room Computers';
                        break;
                        default: $AssetName = '';
                        break;
                }                                            
                    $RoomTable = $RoomTable . "<tr><td>" . $AssetName . "</td><td>"  . $row["Quantity"] . "</td></tr>";                           
                    $RoomDetails[$ArrayCount] = $row["Quantity"];   
                    $ArrayCount = $ArrayCount + 1;       
            }            
            $RoomTable = $RoomTable . "</tbody></table></form>";
            echo $RoomTable; 
            return $RoomDetails;
          
        }
    }
    function UpdateRoomDetails($RoomNumber,$RoomName,$Campus,$Floor,$MaxCapacity,$Chairs,$Tables,$Projector,$Monitors,$RoomComputers,$PowerCords)
    {
        echo 'Test';
         $CampusID = 0;
        switch($Campus){
            case 'Notre Dame Campus': $CampusID = 1;
            break;
            case 'Main Street Campus': $CampusID = 2;
            break;
            default: $CampusID = 0;
            break;
        }
        $FloorID = 0;
        switch ($Floor) {
            case 'Lower Level': $FloorID = 1;
                # code...
                break;
                 case 'Floor 1': $FloorID = 2;
                 break;
                  case 'Floor 2': $FloorID = 3;
                  break;
                 case 'Floor 3': $FloorID = 4;
                 break;           
             case 'Floor 4': $FloorID = 5;
             break; 
              case 'Floor 5': $FloorID = 6;
              break;
     case 'Floor 13': $FloorID = 7;
     break;
      case '3rd Floor': $FloorID = 8;
            default:
               $FloorID = 0;
                break;
        }
       $sql = "call spUpdateRoomDetails ('" .$RoomName ."','" . $RoomNumber . "','" . $CampusID . "','" . $FloorID .
                                      "','" . $MaxCapacity . "','" . $Chairs . "','" . $Tables . "','" . $PowerCords . "','"
                                            .$Projector . "','" . $Monitors . "','" . $RoomComputers . "')";
                                         
      $result = $this->conn->query($sql);
        return 'UpDate Complete';
    }
}

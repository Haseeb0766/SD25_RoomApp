<?php 
session_start();
include("Master.php");
session_start();
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
parse_str($_SERVER['QUERY_STRING']);
$SupplyID =  trim($SupplyID);
$SupplyName =  trim($SupplyName);
$Quantity =  trim($Quantity);
$Description =  trim($Description);

?>
<html>
<header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
      
       <link rel="stylesheet" type="text/css" href="Button.css"></header>
    
<body>
<form action="Access_Supply.php" method="POST">
<table>
<tr><td>Supply ID</td><td><input type="text" readonly="true" name="SupplyID" value="<?php echo $SupplyID ?>"/></td></tr>
<tr><td>Supply </td><td><input type="text"  name="SupplyName" value="<?php echo $SupplyName ?>"/></td></tr>
<tr><td>Quantity </td><td><input type="text"  name="Quantity" value="<?php echo $Quantity ?>"/></td></tr>
<tr><td>Description</td><td><textarea name="Description"><?php echo $Description ?></textarea></td></tr>

</table>
<input type="submit" name="UpdateSupply" value="Save" class="Button" />
</form>
</body>
</html>
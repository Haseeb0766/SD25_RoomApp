<?php
session_start();
require("LoginClass.php");
if(isset($_POST["Login"])){
    $userName =  $_POST["username"];
    $password =  $_POST["Password"];
    $DBconn = new LoginClass();
    $DBconn->connect();
    $DBconn->login($userName, $password);
    $DBconn->close();

}
?>
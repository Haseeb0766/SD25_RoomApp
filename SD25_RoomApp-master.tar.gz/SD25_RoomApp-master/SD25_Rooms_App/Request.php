<?php
session_start();
include("Master.php");
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
?>
<!DOCTYPE html >
<html>
  
    <body>
    <form action="Excute_Request.php" method="POST"/>
          <h1 style="text-align: center" >Need Something?</h1>
          
          <div style="position: absolute;">
          <table>
          <tr><td>Intake Name </td><td><input type="text" name="intakeName" id="intakeName"/></td> </tr>
            <tr><td>Room Name </td><td><input type="text" name="roomName" id="roomName"/></td> </tr>
          <tr><td>Request Type</td><td>
          <Select id="colorselector" name="requestType" >
          <option value="Select" >Select</option>
   <option value="Asset">Asset</option>
   <option value="Room">Room</option>
   <option value="Supply">Supply</option>
</Select></td></tr>
</table>
<div id="Select" class="colors" style="display:none">Please select what you need </div>
<div id="Asset" class="colors" style="display:none"> 
<table>

<tr><td>Number of Chairs</td><td><input type="number" name="ChairNum" id="ChairNum" /></td></tr>
<tr><td>Number of Tables </td><td><input type="number" name="TableNum" id="TableNum"></td></tr>
<tr><td>Number of Power Cords</td><td><input type="number" name="PowerCordNum" id="PowerCordNum" /></td></tr>
<tr><td>Number Moniters</td><td><input type="number" name="MonitorNum" id="MonitorNum" /></td></tr>
<tr><td>Need a Projector?</td><td>Yes<input type="checkbox" name="projectorAsset" value="Yes"></tr>
<tr><td>Need a Digital Box??</td><td>Yes<input type="checkbox" name="digitalBoxAsset" value="Yes"></tr>
<tr><td></tr>
</table>
  </div>
  
<div id="Room" class="colors" style="display:none"> Room Request
<table>

<tr><td>Number of Students</td><td><input type="number" id="NumStudent" name="studentNumber" /></td></tr>
<tr><td>Number of Power Cords</td><td><input type="number" id="numberCord" name="numberCord"  /></td></tr>
<tr><td>Start Date </td><td><input type="Date" id="startDate" name="startDate" /></td></tr>
<tr><td>End Date </td><td><input type="Date" id="endDate" name="endDate"  /></td></tr>
<tr><td>Start Time </td><td><input type="Time" id="startTime" name="startTime" /></td></tr>
<tr><td>End  Time </td><td><input type="Time" id="endTime" name="endTime" /></td></tr>
<tr><td>Need a Projector?</td><td>Yes<input type="checkbox" id="ProjecReq" name="projectorInRoom" /></td></tr><tr><td>
<tr><td>Need a Digital Box??</td><td>Yes<input type="checkbox" name="digitalBoxInRoom" value="Yes"></tr>
</table>

</div>
<div id="Supply" class="colors" style="display:none"> 
<h1 style="text-align: center;" >Select what you need</h1>
<table><tr><td style="text-align: center" > </td>
<table><tr><td> Lysol</td><td>Yes  <input type="checkbox" name="Lysol" /></td></tr>
<tr><td> Paper Towel</td><td>Yes  <input type="checkbox" name="PaperTowel" /></td></tr>
<tr><td> Windex</td><td>Yes  <input type="checkbox" name="Windex" /></td></tr>
<tr><td> Vinegar Water</td><td>Yes  <input type="checkbox" name="VinegarWater" /></td></tr><tr><td>

</table>
 </div>
 <div>
 <input type="submit" id="Cancel" value="Cancel" name="Cancel" >
     <input type="submit" id="submit" name="submit" value="SUBMIT" onclick="submit_animate(this);" >

 </div>
         
     
        </form>
    </body>
    <script>
 $(function() {
        $('#colorselector').change(function(){
            $('.colors').hide();
            $('#' + $(this).val()).show();
            
        });
    });
    </script>
    <script>
    function Cancel()
    {
     
        header("location: Request.php");
    }
    </script>

    <script>
        function submit_animate(target)   {
	$(target).val('submitting...').css({
    'transition-property':'box-shadow, background-image',
    'background-image':'linear-gradient(to right, #e57375 70%, #D32F2F 70%)'
  }).animate({
      'background-position-x': '-100%'
    }, 1000, function () {$(this).val('done').css({ 
      'background-position-x': 0,
      'background-image':'' 
    });
  });
}
</script>
</html>
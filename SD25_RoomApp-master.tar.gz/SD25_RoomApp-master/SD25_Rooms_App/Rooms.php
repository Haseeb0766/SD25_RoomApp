<?php
session_start();
include ("Master.php");
require("RoomsClass.php");
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}

?>
<html>
    <header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
               <link rel="stylesheet" type="text/css" href="Button.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
    </br>
    </br>
    <a  href="#InsertRoom"> <button id="Insert" Class="Button" >Insert</button></a>
    <?php 
    $DBconn = new RoomsClass();
$DBconn->connect();
$DBconn->ReadRooms();
$DBconn->close();
?>
   <div id="InsertRoom" class="overlay">
	<div class="popup">
		<a class="close" href="#">&times;</a>
     <form action="Rooms_Access.php" method="POST" >
     <div id="insert"  >
<table>
<tr>
<td>Room Name:</td>
<td><input type="text" name="RoomName"/> </td>
</tr>
<tr>
<td>Room Number</td>
<td><input type="text" name="RoomNumber"/></td>
</tr>
<tr>
<td>Campus</td>
<td><select id="colorselector" name="colorselector" >
<option value="None" >Select </option>
<option value="NortdameCampus" >Campus 1 </option>
<option value="MainstCampus" >Campus 2 </option>
</td></select>
</tr>
<tr>
<td>Floor</td>
<td><select id="NortdameCampus" name="NortdameCampus" style="display: none;"  >
<option> Select </option>
<option>Lower Level </option> 
<option> Floor 1 </option> 
<option>Floor 2 </option>
<option>Floor 3 </option>
<option> Floor 4 </option>
<option> Floor 5 </option>
</select>
<select id="MainstCampus" name="MainstCampus" style="display: none;"  >
<option> Floor 13 </option> 
<option>3rd Floor </option>
</td>
</tr>
<tr>
<td>Capacity</td>
<td><input type="Number" name="Capacity"/> </td>
</tr>
<tr>
<td>Max Capacity</td>
<td><input type="Number" name="MaxCapacity"/></td>
</tr>
<tr>
<td>Status</td>
<td><input type="text" name="Statuse"/></td>
</tr>
<tr>
<td>Description</td>
<td><textarea name="Description"/></textarea></td>
</tr>
</table>

     </div>
<button Class="Button" name="Save" >Save</button>
     </div>
     </div>

    </body>
<script type="text/javascript">
  $(document).ready(function () {
    $('#colorselector').change(function() {
      if ($(this).val() == 'NortdameCampus') {
        $('#NortdameCampus').show();
        $('#MainstCampus').hide();
        
      } else if ($(this).val() == 'MainstCampus') {
        $('#MainstCampus').show();
        $('#NortdameCampus').hide();
      }
      else{
           $('#MainstCampus').hide();
            $('#NortdameCampus').hide();
      }
    });
  });
</script>
    </html>
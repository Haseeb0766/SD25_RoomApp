<?php
session_start();
include("Master.php");
require("InventoryClass.php");
parse_str($_SERVER['QUERY_STRING']);
$Quantities = $_POST["AssetQuantity"];
$AssetID = "";
    switch($_POST["Assets"]){
        case 'Chair' :            
            $AssetID = 1;
            break;
        case 'Table' :            
            $AssetID = 2;
            break;
        case 'Power Cord' :            
            $AssetID = 3;
            break;
        case 'Projector' :            
            $AssetID = 4;
            break;
        case 'Monitor' :            
            $AssetID = 5;
            break;
        case 'Room Computer' :            
            $AssetID = 6;
            break;
        default:            
            $AssetID = 0;
            break;
    }
if(isset($_POST["SaveUpdate"])){
    //echo  "<br/><br/>" . $_POST["action"];
    if($_POST["action"] == 'UpdateRoom'){
        $RoomName = $_POST["RoomName"];
        //echo "<br></br>" . $RoomName;
        $DBconn = new InventoryClass();
        $DBconn->connect();
        $DBconn->UpdateAssetInRoom($RoomName, $AssetID, $Quantities);
        $DBconn->close();
    }
    else if($_POST["action"] == 'UpdateStock'){
        $DBconn = new InventoryClass();
        $DBconn->connect();
        $DBconn->UpdateAssetInStock($AssetID, $Quantities);
        $DBconn->close();
    }
}
?>
<html>
    <header>  
       <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
    <br/>
    
    </body>
	   </html>

<?php
$DBconn = new InventoryClass();
$DBconn->connect();
//$DBconn->readInventory();
$DBconn->close();
?>

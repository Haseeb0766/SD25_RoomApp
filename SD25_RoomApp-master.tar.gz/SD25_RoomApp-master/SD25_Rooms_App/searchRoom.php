<!DOCTYPE html>
<html>
    <body>
        <div style="position: absolute;
  margin: auto;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 500px;
  height: 300px;
  background-color: #ccc;
  border-radius: 3px;" >
            <input type="text" placeholder="Room Name" id="searched" style="text-align: center" />
            <input type="button" value="search" id="Search" />
            </br>
            <select>
                <option>Selet Room Availablity</option>
                <option>Empty Rooms</option>
                <option>Empty On Date</option>
            </select>
            <div style="visibility: hidden"  >
                This Dic will have a Celender in it and it will help the User to search the room that is empty on specific date.</div>
        </div>
    </body>
</html>
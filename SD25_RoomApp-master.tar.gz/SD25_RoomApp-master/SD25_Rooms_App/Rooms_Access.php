<?php 
session_start();
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
require("RoomsClass.php");
if(isset($_POST["Save"])){
$RoomName =  $_POST["RoomName"];
$RoomNumber =  $_POST["RoomNumber"];
$CampusID =  $_POST["colorselector"];
if( $_POST["NortdameCampus"] == NULL)
{
    
    $FloorID  = $_POST["MainstCampus"];
}
else{
    $FloorID  = $_POST["NortdameCampus"];
}
$Statuse = $_POST["Statuse"];
$Capacity = $_POST["Capacity"];
$MaxCapacity = $_POST["MaxCapacity"];
$Description = $_POST["Description"];
 $DBconn = new RoomsClass();
 $DBconn->connect();
  $result =  $DBconn->Insert($RoomName,$RoomNumber,$CampusID,$FloorID,$Capacity,$MaxCapacity,$Statuse,$Description); 
 $DBconn->close();
 header('location:Rooms.php');
}
if(isset($_POST["SaveEdit"])){
 $RoomName =  $_POST["RoomName"];
 $RoomNumber =  $_POST["RoomNumber"];
 $CampusID =  $_POST["colorselector"];
 $MaxCapacity = $_POST["MaxCapacity"];
 $Chairs = $_POST["Chairs"];
 $Tables = $_POST["Tables"];
 $Projectro = $_POST["Projectors"];
 $Monitors = $_POST["Monitors"];
 $RoomComputers = $_POST["RoomComp"];
  $PowerCords = $_POST["PowerCords"];
if( $CampusID == "None"){
    echo 'North';
    $FloorID  = $_POST["MainstCampus"];
}
else{
   echo 'HEre';
    $FloorID  = $_POST["NortdameCampus"];
}

$DBconn = new RoomsClass();
 $DBconn->connect();
 $result =  $DBconn->UpdateRoomDetails($RoomNumber,$RoomName,$CampusID,$FloorID,$MaxCapacity,$Chairs,$Tables,$Projectro,$Monitors,$RoomComputers,$PowerCords); 
 $DBconn->close();
 header("location:Rooms.php");
}
<html>
   <title>Search </title>
        <body>
            <script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".box").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>
<h1 style="text-align: center" >Looking for Something ?</h1>
            <div id="SelectOp"   >
<table>
    <tr>

    </tr>
    <tr><td><select >
        <option value="red" >Select Item</option>
        <option value="green" >Room</option>
        <option value="Yeellow" >Assestes</option>
        </select>
                </div>
                <div class="red box" ></div>
                 <div  class="green box " >
                     <table>
                         <tr><td>
                     <input type="Radio" value="Empty" />Empty </td></tr>
                     <tr>
                         <td>
                   
                     Number of Chair's <input type="number" id="ChairNum"/></td></tr>
                     </table>
                     </div>
                  <div class="Yeellow box" > Here you will search for Assestes </div>
                
         </body>
  </html>

<?php
session_start();
include("Master.php");
require("InstructorClass.php");
parse_str($_SERVER['QUERY_STRING']);
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
$DBconn = new InstructorClass();
$DBconn->connect();
$DBconn->readInstructor();
$DBconn->close();
?>
<html>
    <header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
  	<a  href="#popup2"> <button id="Insert"  style="width:100px;
  margin: 10em auto;
  padding: 1em;
  text-transform: uppercase;
  border: 0px;
  border-radius: 3px;
  background-image: linear-gradient(to right, #f44336 0%, #f44336 20px);

  transition: .50s;
  color: #fff;
  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.25);" >Insert</button></a>
      <div id="popup2" class="overlay">
	<div class="popup">
		<a class="close" href="#">&times;</a>
     <form action="Acces_Instructor.php" method="POST" >
     <div id="insert"  >
        <h1 style="text-align:center" >New Instructor </h1>
            <table>
                <tr><td>Email</td><td><input type="email" name="Email" /></td></tr>
                <tr><td>First Name</td><td><input type="text" name="firstName"  /></td></tr>
                 <tr><td>Last Name</td><td><input type="text" name="LastName"/></td></tr>
                   <tr><td>Select Campus</td>
                   <td><select name="Campus" >
                   <option> Campus 1 </option>
                   <option> Campus 2</option>
                   </select></td></tr>
                              <tr><td>Description</td><td><textarea type="text" name="description"></textarea></td></tr>
                              </table>
                            <input type="Submit" name="Insert"  style="width:100px;

  padding: 1em;
  text-transform: uppercase;
  border: 0px;
  border-radius: 3px;
  background-image: linear-gradient(to right, #f44336 0%, #f44336 20px);

  transition: .50s;
  color: #fff;
  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.25);"/>
               </div>
               </form>
                      </div>
                        </div>
                                
                        

        </body>
   
        </html>
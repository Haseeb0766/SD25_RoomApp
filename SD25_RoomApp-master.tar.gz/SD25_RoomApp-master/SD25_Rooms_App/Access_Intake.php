<?php 
session_start();
require("IntakeClass.php");
if(isset($_POST["Save"])){
   
    $InTakeID =  $_POST["InTakeID"];
    $StartDate =  $_POST["StartDate"];
    $EndDate = $_POST["EndDate"];
    $StartTime =  $_POST["StartTime"]; 
    $EndTime =  $_POST["EndTime"];
    $InstructorEmail =  $_POST["InstructorEmail"];
    $NumberOfStudents =  $_POST["NumberofStudents"];
    $Description = $_POST["Description"];
    echo $InstructorEmail;
    $DBconn = new InTakeClass();
    $DBconn->connect();

    $result = $DBconn->InesertInTake($InTakeID, $StartDate,
                                     $EndDate,$StartTime,$EndTime,
                                     $InstructorEmail,$NumberOfStudents,$Description); 
    $DBconn->close();
}


?>
<?php
session_start();
include("Master.php");
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  //header("location:Login.php");
}
require("RoomsClass.php");
parse_str($_SERVER['QUERY_STRING']);
$RoomName =  trim($RoomName);
$DBconn = new RoomsClass();
$DBconn->connect();
$RoomDetails = $DBconn->ReadRoomDetails($RoomName);
$DBconn->close();
?>

<html>
<header>
 <link rel="stylesheet" type="text/css" href="TestStyle.css">  
         <link rel="stylesheet" type="text/css" href="Button.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css">
</header>

<body>
<a href="#EditRoom">
<input type="Button" class="Button" value="Edit"/></a>
 <div id="EditRoom" class="overlay">
	<div class="popup">
		<a class="close" href="#">&times;</a>
<div style="Display:visible" >
<form action="Rooms_Access.php" method="POST">
<table>
<tr>
<td>Room Number</td>
<td><input type="text" name="RoomNumber" value="<?php echo $RoomDetails[0];?>" /></td>
</tr>
<tr>
<td>Room Name:</td>
<td><input type="text" name="RoomName" readonly="true" value="<?php echo $RoomDetails[1];?>" /> </td>
</tr>
<tr>
<td>Campus</td>
<td>
<?php 
echo "<select id='colorselector' name='colorselector'>";
echo "<option value='None'>Select Campus</option>";
echo "<option ";
if ($RoomDetails[2] == 'Notre Dame Campus' ) echo 'selected';
echo " value='Notre Dame Campus'>Notre Dame Campus</option>";
echo "<option ";
if ($RoomDetails[2] == 'Main Street Campus' ) echo 'selected';
echo " value='Main Street Campus'>Main Street Campus</option>";
echo "</select>";
?>
</td>
</tr>
<tr>
<td>Floor</td>
<td>
<?php 
echo "<select id='NortdameCampus' name='NortdameCampus' ";
echo "<option value='None'>Select Floor</option>";
echo "<option ";
if ($RoomDetails[3] == '0' ) echo 'selected';
echo " value='Lower Level'>Lower Level</option>";
echo "<option ";
if ($RoomDetails[3] == '1' ) echo 'selected';
echo " value='Floor 1'>Floor 1</option>";
echo "<option ";
echo "<option ";
if ($RoomDetails[3] == '2' ) echo 'selected';
echo " value='Floor 2'>Floor 2</option>";
echo "<option ";
echo "<option ";
if ($RoomDetails[3] == '3' ) echo 'selected';
echo " value='Floor 3'>Floor 3</option>";
echo "<option ";
echo "<option ";
if ($RoomDetails[3] == '4' ) echo 'selected';
echo " value='Floor 4'>Floor 4</option>";
echo "<option ";
echo "<option ";
if ($RoomDetails[3] == '5' ) echo 'selected';
echo " value='Floor 5'>Floor 5</option>";
echo "</select>";

echo "<select id='MainstCampus' name='MainstCampus' style='display: none;'";
echo "<option value='None'>Select Floor</option>";
echo "<option ";
if ($RoomDetails[4] == '6' ) echo 'selected';
echo " value='Floor 3'>Floor 3</option>";
echo "<option ";
echo "<option ";
if ($RoomDetails[4] == '7' ) echo 'selected';
echo " value='Floor 13'>Floor 13</option>";
echo "</select>";
?>
</td>
</tr>
<tr>
<td>Max Capacity</td>
<td><input type="Number" name="MaxCapacity" value="<?php echo $RoomDetails[4];?>" /></td>
</tr>
<tr>
<td>Chairs</td>
<td><input type="text" name="Chairs" value="<?php echo $RoomDetails[5];?>" /> </td>
</tr>
<tr>
<td>Tables</td>
<td><input type="text" name="Tables" value="<?php echo $RoomDetails[6];?>"/> </td>
</tr>
<tr>
<td>Power Cords</td>
<td><input type="text" name="PowerCords" value="<?php echo $RoomDetails[7];?>" /> </td>
</tr>
<tr>
<td>Projectors</td>
<td><input type="text" name="Projectors" value="<?php echo $RoomDetails[8];?>"/> </td>
</tr>
<tr>
<td>Monitors</td>
<td><input type="text" name="Monitors" value="<?php echo $RoomDetails[9];?>" /> </td>
</tr>
<tr>
<td>Room Computers</td>
<td><input type="text" name="RoomComp" value="<?php echo $RoomDetails[10];?>" /> </td>
</tr>
</table>
<input type="submit" name="SaveEdit" value="Save" class="Button"/>
</div>
</form>
</div>
</div>
</body>
<script type="text/javascript">
  $(document).ready(function () {
    $('#colorselector').change(function() {
      if ($(this).val() == 'Notre Dame Campus') {
        $('#NortdameCampus').show();
        $('#MainstCampus').hide();
        
      } else if ($(this).val() == 'Main Street Campus') {
        $('#MainstCampus').show();
        $('#NortdameCampus').hide();
      }
      else{
           $('#MainstCampus').hide();
            $('#NortdameCampus').hide();
      }
    });
  });
</script>
</html>

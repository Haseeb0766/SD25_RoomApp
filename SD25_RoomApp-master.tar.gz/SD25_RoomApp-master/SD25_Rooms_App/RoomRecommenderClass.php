<?php
class RoomRecommenderClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}

    function connect ()
    {
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);                                 
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }

    function close()
    {
        $this->conn->close();
    }

    function CompareRoomCapacity($StudentsNum){
        $sql = "call spRoom (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'readAllRooms')";        
        $result = $this->conn->query($sql);
        $count = 0;
        $Rooms = array(array(), array(), array(), array());
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){                                               
                $Rooms[$count][0] = $row["RoomNumber"];
                $Rooms[$count][1] = $row["RoomName"];
                $Rooms[$count][2] = $row["MaximumCapacity"];
                $RoomCapacity = $Rooms[$count][2];                
                if($StudentsNum == $RoomCapacity)
                {
                    $Rooms[$count][3] = 10;
                }                
                else if($StudentsNum < $RoomCapacity && $StudentsNum > ($RoomCapacity - 3))
                {
                    $Rooms[$count][3] = 7;
                }
                else if($StudentsNum > $RoomCapacity && $StudentsNum < ($RoomCapacity +3))
                {
                    $Rooms[$count][3] = 5;
                }
                else
                {
                    $Rooms[$count][3] = 0;
                }
                $count = $count + 1; 
            }                         
        }
        return $Rooms;
    }

    function CompareDateAndTime($RoomsArray, $StartDate, $EndDate, $StartTime, $EndTime){
        $Rooms = $RoomsArray;
        for($i=0;$i<count($RoomsArray);$i++){
            if($RoomsArray[$i][3] > 0){
                $count = 0;                
                $sql = "call spRoomSchedule (NULL,'" . $RoomsArray[$i][1] . "', NULL, NULL, NULL, NULL, NULL, NULL, 'readRoomSchedule')";
                //echo $sql;
                $result = $this->conn->query($sql);                
                if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){ 
                        if($row["StartDate"] != null || $row["EndDate"] != null || $row["StartTime"] != null || $row["EndTime"] != null)
                        {
                            $STARTDATE = DateTime::createFromFormat('Y-m-d', $row["StartDate"])->format('Y-m-d');
                            $ENDDATE = DateTime::createFromFormat('Y-m-d', $row["EndDate"])->format('Y-m-d');
                            $STARTTIME = date("H:i:s",strtotime($row["StartTime"]));
                            $ENDTIME = date("H:i:s",strtotime($row["EndTime"]));
                            if(($STARTDATE <= $StartDate && $ENDDATE > $StartDate) || ($STARTDATE >= $StartDate && $STARTDATE < $EndDate)){
                                if(($STARTTIME <= $StartTime && $ENDTIME > $StartTime) || ($STARTTIME >= $StartTime && $STARTTIME < $EndTime)){
                                    $Rooms[$i][3] = 0;
                                }                                
                            }
                        }                        
                    }
                }
            }            
        }
        return $Rooms;
    }

    function DisplayRecommended($Rooms){
        echo "<br/>";
        echo (count($Rooms) . " rooms recommended");
        echo "<br/>";
        $recommended = "<table><tr><th>Room #</th><th>Room Name</th><th>Room Capacity</th><th>Rate</th></tr>";
        for($i=0;$i<count($Rooms);$i++){
            $recommended = $recommended . "<tr><td>" . $Rooms[$i][0] . "</td>"
                                        . "<td>" . $Rooms[$i][1] . "</td>"
                                        . "<td>" . $Rooms[$i][2] . "</td>"
                                        . "<td>" . $Rooms[$i][3] . "</td>"                                        
                                        . "</tr>";            
        }
        $recommended = $recommended . "</table>";
        echo $recommended;
    }
}
?>
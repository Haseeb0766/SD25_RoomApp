<?php
class InTakeClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}
    function connect (){
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);   
                                              
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }
    function close()
    {
        $this->conn->close();
    }
    function ReadAllIntakes() 
    {

       
           $sql = "call spIntake(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,'readAllIntakes')";
 $result = $this->conn->query($sql);
                    if($result->num_rows > 0)
        {            
             $InTakeTable = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Intake ID</th>
                        <th>Instructor Email </th>
                        <th> Start Date</th>
                        <th>Start Time</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $InTakeTable = $InTakeTable . "<tr><td>"  . $row["IntakeID"] . "</td>" .
                                                     "<td>" . $row["InstructorEmail"] . "</td>" . 
                                                     "<td>" . $row["StartDate"]. "</td>" .
                                                     "<td>" . $row["StartTime"]. "</td>" .                                                   
                                                     "<td><input type='Submit' name='edit' value='Edit'" 
                                                     ."formaction='EditIntake.php?"
                ."IntakeID=".$row['IntakeID']          
                                  
             ."'/></td>"
            ."<td><input type='Submit' name='SubmitDEL' value='Delete'"
            ."formaction='Access_Intakes.php?"
                ."IntakeID=".$row['IntakeID']                              
             ."'/></td></tr>";               
            }            
            $InTakeTable = $InTakeTable . "</tbody></table></form>";
            echo $InTakeTable; 
          
        }
    }
    function InesertInTake($InTakeID,$StartDate,$EndDate,$StartTime,$EndTime,$InstructorEmail,$NumberOfStudents,$Description)
    {
       
        echo 'TEst';
         $sql = "call spIntake('" .$InTakeID . "','". $StartDate . "','". $EndDate ."','". $StartTime
                             ."','". $EndTime ."','". $InstructorEmail . "','". $NumberOfStudents 
                            . "','". $Description ."','c')";
                            echo $sql;
                         $result = $this->conn->query($sql);
 return 'Hello world';
 echo 'Success';
     }

function getInstructors() 
{
$sql = "SELECT * FROM tbUser where UserType='Instructor'";
$result = $this->conn->query($sql);
$Instructors = array(array(), array());
$count = 0;
if($result->num_rows > 0)
{
while($row = $result->fetch_assoc()){    
    $Instructors[$count][0] = $row["Email"];
    $Instructors[$count][1] = $row["FirstName"] . " " . $row["LastName"];
    $count = $count + 1;
}
}
return $Instructors;
}
function DeleteIntake ($IntakeID)
{
     $sql = "call spIntake('" . $IntakeID . "', NULL, NULL, NULL, NULL, NULL, NULL, NULL,'d')";
 $result = $this->conn->query($sql);
}
function ReadOneIntake($IntakeID )
{
    echo 'Test';
     $sql = "call spIntake('" . $IntakeID . "', NULL, NULL, NULL, NULL, NULL, NULL, NULL,'readIntake')";
 $result = $this->conn->query($sql);
 $Data = array();
  if($result->num_rows > 0)
        {
               while($row = $result->fetch_assoc()){
                 $Data[0] = $row['StartDate'];
                 $Data[1] = $row['EndDate'];
                 $Data[2] = $row['StartTime'];
                 $Data[3] = $row['EndTime'];
                 $Data[4] = $row['InstructorEmail'];
                 $Data[5] = $row['NumOfStudents'];
                 $Data[6] = $row['Description'];
                 
               }          
        }
        return $Data;

 
}
function UpdateEdit($IntakeID,$StartDate,$EndDate,$StartTime,$EndTime,$InstructorEmail,$NumberofStudents,$Description)
{

     $sql = "call spIntake('" . $IntakeID . "','" . $StartDate . "','" . $EndDate . "','" . $StartTime . "','" . $EndTime . "','" .
                                $InstructorEmail . "','" . $NumberofStudents . "','" . $Description . "','u')";
                              
    $result = $this->conn->query($sql);
    return 'Update Success';
}
function myGroups($Email)
{
    
  $sql =  "call spIntake(Null,Null,Null,Null,Null,'". $Email . "',Null,Null,'InstructorIntakes')";
   $result = $this->conn->query($sql);
   if($result->num_rows > 0)
        {            
             $MyIntakes = "<form action='' method='POST'><table>
                <thead>
                    <tr>
                        <th>Intake ID</th>
                        <th>Instructor Email </th>
                        <th> Start Date</th>
                        <th>Start Time</th>
                        
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $MyIntakes = $MyIntakes . "<tr><td>"  . $row["IntakeID"] . "</td>" .
                                                     "<td>" . $row["IntakeID"] . "</td>" . 
                                                     "<td>" . $row["Description"]. "</td>" .
                                                     "<td>" . $row["StartTime"]. "</td>"                                                    
                                                                         
             ."</tr>";               
            }            
            $MyIntakes = $MyIntakes . "</tbody></table></form>";
            echo $MyIntakes; 
        
}
else 
{
     echo "<script> alert('You have 0 groups PLease go back home');</script>";
}
 }
}

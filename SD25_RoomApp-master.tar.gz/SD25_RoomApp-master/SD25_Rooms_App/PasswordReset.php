<html>
<head>
<link rel="stylesheet" type="text/css" href="Button.css">
</head>
<body>
<div id="Email" style=" border: solid gray 1px; border-radius: 50px;
 background:blur(5px); background-color:white;  width: 30%; margin: 90px auto; padding: 50px; ">
 <form action="Access_PasswordReset.php" method="POST">
 <h1 style="text-align:center">Please Enter your email</h1>
<table>
<tr><td>Email</td><td><input type="Email" id="Email" name="Email" placeholder="Email"/></td></tr>
<tr><td><input type="submit" id="sendCode" value="Submit" class="Button" /></td></tr></table>
</div>
</form>
</br>

</body>
</html>
<?php
session_start();
class RequestClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}

    function connect ()
    {
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);                                 
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }

    function close()
    {
        $this->conn->close();
    }

    function MakeRequest($RequestType, $RoomName, $RequestBy, $IntakeID, $StartDate, $EndDate, $StartTime, $EndTime, $RequestDate)
    {                
        if($RequestType == 'Room'){
            $sql = "call spRequest('-1', NULL,'"  . $RequestBy . "', '"  . $IntakeID . "', '"  . $RequestType . "', '"  . $StartDate . "', '"  . $EndDate . "', '"  . $StartTime . "', '"  . $EndTime . "', '"  . $RequestDate . "', NULL, NULL, 'Pending', 'None', 'c')";
        }
        else {
            $sql = "call spRequest('-1', '" . $RoomName . "', '"  . $RequestBy . "', '"  . $IntakeID . "', '"  . $RequestType . "', NULL, NULL, NULL, NULL, '"  . $RequestDate . "', NULL, NULL, 'Pending', 'None', 'c')";
        }
        //echo $sql;
        $result = $this->conn->query($sql); 
        if($result->num_rows > 0)
        {    
            while($row = $result->fetch_assoc())
            {
                $response = $row['Result'];  
                if($response == 'Request ID created'){
                    $NewRequestID = $row['RequestID'];                                      
                }  
                else {
                    $NewRequestID = 'Request failed';
                }                             
            }                                                                              
        }  
        else {
            $NewRequestID = 'Request failed';
        }   
        return $NewRequestID;       
    } 

    function SaveRoomRequestDetails ($RequestID, $StudentNumber){
        $RoomQuantity = 1;                
        $sql = "call spRequestDetail('-1', '" . $RequestID . "', 'Room', NULL, NULL, NULL, NULL, '"  . $RoomQuantity . "', '"  . $StudentNumber . "', 'c')";
        //echo $sql;
        $result = $this->conn->query($sql);
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $response = $row['Result'];                    
            }
        }
        else{
            $response = 'Request Details Failed';
        }       
        return $response;        
    }

    function SaveAssetRequestDetails ($RequestID, $Asset, $AssetQuantity){
        $AssetID = 0;
        switch($Asset){
            case 'Chair':
                $AssetID = 1;
                break;
            case 'Table':
                $AssetID = 2;
                break;
            case 'Power Cord':
                $AssetID = 3;
                break;
            case 'Projector':
                $AssetID = 4;
                break;
            case 'Monitor':
                $AssetID = 5;
                break;
            case 'Room Computer':
                $AssetID = 6;
                break;
            default:
                $AssetID = 0;
        }
        $sql = "call spRequestDetail('-1', '" . $RequestID . "', 'Asset', '"  . $AssetID . "', '"  . $AssetQuantity . "', NULL, NULL, NULL, NULL, 'c')";
        //echo $sql;
        $result = $this->conn->query($sql);
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $response = $row['Result'];                    
            }
        }
        else{
            $response = 'Request Details Failed';
        }       
        return $response;        
    }

    function SaveSupplyRequestDetails ($RequestID, $Supply, $SupplyQuantity){
        $SupplyID = 0;
        switch($Supply){
            case 'Lysol':
                $SupplyID = 1;
                break;
            case 'Vinegar Water':
                $SupplyID = 2;
                break;
            case 'Paper Towel':
                $SupplyID = 3;
                break;
            case 'Windex':
                $SupplyID = 4;
                break;            
            default:
                $SupplyID = 0;
        }                       
        $sql = "call spRequestDetail('-1', '" . $RequestID . "', 'Supply', NULL, NULL, '"  . $SupplyID . "', '"  . $SupplyQuantity . "', NULL, NULL, 'c')";
        //echo $sql;
        $result = $this->conn->query($sql);
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $response = $row['Result'];                    
            }
        }
        else{
            $response = 'Request Details Failed';
        }       
        return $response;        
    }

    function ViewRequests()
    {
      
        //Check from Session if Admin or Instructor 
        
        $sql = "call spRequest (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'r')";
        echo "<br/><br/>";
        //echo $sql;
        $result = $this->conn->query($sql);
 
        if($result->num_rows > 0)
        {
             $RequestTable = '<form Method="POST" action=""><table>          
                <tbody>      
                    <tr>
                        <th>Request ID</th>
                        <th>Requested by</th>
                        <th>Request Type</th>
                        <th>Intake</th>
                        <th>Statuse</th>
                        <th></th>
                    </tr>';                                
            while($row = $result->fetch_assoc()){
                $RequestTable = $RequestTable . '<tr><td>'  . $row['RequestID'] . '</td>' .
                                                     '<td>' . $row['RequestBy'] . '</td>' . 
                                                     '<td>' . $row['RequestType']. '</td>' .
                                                     '<td>' . $row['IntakeID']   . '</td>' .
                                                     '<td>' . $row['Status'] . '</td>' .
                                                     '<td><input type="submit" value="View Details" name="ViewDetails" '.
                                                           'formaction="ViewRequest.php?RequestID=' . $row["RequestID"] . '"></td>' . 
                                                '</tr>';               
            }
            $RequestTable = $RequestTable . '</tbody></table></form>';            
            echo $RequestTable; 
        }
        else{
            echo "No Data Found";
        }
    }

    function ViewRequestByID($RequestID)
    {        
        $sql = "call spRequest ('" . $RequestID . "', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'readByRequest')";
        //echo $sql;
        $result = $this->conn->query($sql);
 
        if($result->num_rows > 0)
        {      
            $request = "<form action='' METHOD='POST'>   
                          <table>";
            while($row = $result->fetch_assoc()){
                $_SESSION["RequestID"] = $RequestID;
                $_SESSION["StartDate"] = $row['StartDate'];
                $_SESSION["EndDate"] = $row['EndDate'];
                $_SESSION["StartTime"] = $row['StartTime'];
                $_SESSION["EndTime"] = $row['EndTime'];
                 $_SESSION["RequestType"] = $row['RequestType'];
                       $request = $request . "<tr><td><label for='requestedBy'>Request By:</label></td><td><input type='text' id='requestBy' name='requestedBy' value='" . $row['RequestBy'] . "' readonly='true' style='outline:none; border:none;'></td></tr>
                                              <tr><td><label for='requestDate'>Request Date:</label></td><td><input type='text' id='requestDate' name='requestDate' value='" . $row['RequestDate'] . "' readonly='true' style='outline:none; border:none;'></td></tr>
                                              <tr><td><label for='intakeID'>Intake:</label></td><td><input type='text' id='intakeID' name='intakeID' value='" . $row['IntakeID'] . "' readonly='true' style='outline:none; border:none;'></td></tr>";
                       if($row['RequestType'] == 'Room'){
                            $request = $request . "<tr><td><label for='startDate'>Start Date:</label></td><td><input type='text' id='startDate' name='startDate' value='" . $row['StartDate'] . "' readonly='true' style='outline:none; border:none;'></td></tr>
                                                   <tr><td><label for='endDate'>End Date:</label></td><td><input type='text' id='endDate' name='endDate' value='" . $row['EndDate'] . "' readonly='true' style='outline:none; border:none;'></td></tr>
                                                   <tr><td><label for='startTime'>Start Time:</label></td><td><input type='text' id='startTime' name='startTime' value='" . $row['StartTime'] . "' readonly='true' style='outline:none; border:none;'></td></tr>
                                                   <tr><td><label for='endTime'>End Time:</label></td><td><input type='text' id='endTime' name='endTime' value='" . $row['EndTime'] . "' readonly='true' style='outline:none; border:none;'></td></tr>";
                       }                                                  
                       $request = $request . "<tr><td><label for='status'>Status:</label></td><td><input type='text' id='status' name='status' value='" . $row['Status'] . "' readonly='true' style='outline:none; border:none;'></td></tr>
                                              <tr><td><label for='description'>Description:</label></td><td><input type='text' id='description' name='description' value='" . $row['Description'] . "' readonly='true' style='outline:none; border:none;'></td></tr>";
            }
            //$request = $request . "</table></form>";      
            //echo htmlspecialchars($request);
            return $request;                         
        }
        else{
            echo "No Data Found";
        }        
    }

    function ViewRequestDetails($RequestID)
    {           
        $sql = "call spRequestDetail('-1'," . $RequestID . ", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'r')";
        //echo $sql;
        $result = $this->conn->query($sql);             

        if($result->num_rows > 0){ 
            $requestDetail = "";             
            while($row = $result->fetch_assoc()){
                $_SESSION["NumOfStudents"] = $row['StudentNumber'];
                $requestType = $row['RequestType'];                
                if($requestType == 'Room'){                    
                    $requestDetail = $requestDetail . "<tr><td>Rooms</td><td>" . $row['RoomQuantity'] . "</td></tr>
                                                      <tr><td>Number of Students</td><td>" . $row['StudentNumber'] . "</td></tr>";  
                }                              
                else if($requestType == 'Asset'){                    
                    $requestDetail = $requestDetail . "<tr><td>" . $row['AssetName'] . "</td><td>" . $row['AssetQuantity'] . "</td></tr>";                                                      
                }
                else if($requestType == 'Supply'){
                    $requestDetail = $requestDetail . "<tr><td>" . $row['SupplyName'] . "</td><td>" . $row['SupplyQuantity'] . "</td></tr>";                                                      
                }                
            }            
        }
        else{
            //echo "nothing to display";
        }
        $requestDetail = $requestDetail . "</table></form>";
        return $requestDetail;
    }
    function ViewMyRequests($Email)
    {   
        $sql = "call spRequest (NULL, NULL,'" . $Email . "', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MyReq')";
        $result = $this->conn->query($sql);
 
        if($result->num_rows > 0)
        {
             $MyRequestTable = "<form><table>
                <thead>
                    <tr>
                        <th>Request ID </th>
                        <th>Requested by</th>
                        <th>Request Type</th>
                        <th>Intake</th>
                        <th>Statuse</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>";
            while($row = $result->fetch_assoc()){
                $MyRequestTable = $MyRequestTable . "<tr><td>"  . $row["RequestID"] . "</td>" .
                                                     "<td>" . $row["RequestBy"] . "</td>" . 
                                                     "<td>" . $row["RequestType"]. "</td>" .
                                                     "<td>" . $row["IntakeID"]   . "</td>" .
                                                     "<td>" . $row["Status"] . "</td>" .
                                                     "<td><input type='submit' value='View Details'".
                                                           "formaction='ViewRequest.php?RequestID=" . $row["RequestID"] . "'/></td>" . 
                                                "</tr>";               
            }
            $MyRequestTable = $MyRequestTable . "</tbody></table></form>";
            echo $MyRequestTable; 
    }
    else
    {
        echo "<script> alert('You have made 0 Requests');</script>";
    }
}

}
?>
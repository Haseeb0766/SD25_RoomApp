<?php
session_start();
require("InstructorClass.php");
 $Email =  $_POST["Email"];
   require_once("Mail.php");
    $Password = (rand(100000000,999999999));
 $from = "haseeb.ahmad@robertsoncollege.net";
 $to = $Email;
 $subject = "Hi!";
 $body = "Hello there:,\n\nThis is Admin of Robertson Bot\nYou recently requested for your password to be reseted. Please use this Password to log in." . $Password . "\n Link to the Robertson Bot http://localhost/SD25_Rooms_App/Login.php";
 
 $host = "ssl://smtp.gmail.com";
 $username = "haseeb.ahmad@robertsoncollege.net";
 $password = "haseebaqib1";
 
 $headers = array (
   'From' => $from,
   'To' => $to,
   'Subject' => $subject);

 $smtp = Mail::factory('smtp', array (
     'host' => $host,  
     'port' => '465',   
     'auth' => true,
     'username' => $username,
     'password' => $password));
 
 $mail = $smtp->send($to, $headers, $body);
 
 if (PEAR::isError($mail)) {
   return 0;
   header("location:PasswordReset.php");
  } else {
        echo 'Here';
$DBconn = new InstructorClass();
$DBconn->connect();
$DBconn->ResetPassword($Email,$Password);
$DBconn->close();
header("location:Login.php");
   return 1;
  }

?>
<?php 
session_start();

if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
require("IntakeClass.php");
parse_str($_SERVER['QUERY_STRING']);
$IntakeID =  trim($IntakeID);
$DBconn = new InTakeClass();
$DBconn->connect();
 $Data =  $DBconn->ReadOneIntake($IntakeID);
$DBconn->close();
echo $Data[0];
?>
<html>
    <header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css">
       <link rel="stylesheet" type="text/css" href="Button.css"></header>
    
<body>
</br>
</br>
</br>
<form action="Access_Intakes.php" method="POST" >
<table>
<tr>
<td>Intake ID</td>
<td><input type="text" name="InTakeID" value="<?php echo $IntakeID ?>" /> </td>
</tr>
<tr>
<td>Start Date:</td>
<td><input type="text" name="StartDate" value="<?php echo $Data[0] ?> " /> </td>
</tr>
<tr>
<td>End Date</td>
<td><input type="text" name="EndDate" value="<?php echo $Data[1] ?> " /></td>
</tr>
<tr>
<td>Start Time</td>
<td><input type="text" name="StartTime" value="<?php echo $Data[2] ?> " /></td>
</tr>
<tr>
<tr>
<td>End Time</td>
<td><input type="text" name="EndTime" value="<?php echo $Data[3] ?> " /> </td>
</tr>
<tr><td>Select Instructor </td>
<td>
<select name="InstructorEmail">
<?php 
$DBconn = new InTakeClass();
$DBconn->connect();
$Instructors = $DBconn->getInstructors(); 
$DBconn->close();
for($i=0;$i<count($Instructors);$i++){
   
echo "<option ";
 if ($Instructors[$i][0] == $Data[4] ) echo 'selected';
echo " value='{$Instructors[$i][0]}'>{$Instructors[$i][1]}</option>";
}
?>
</select></td>
</tr>
<tr>
<td>Number of Students</td>
<td><input type="text" name="NumberofStudents" value="<?php   echo$Data[5]; ?> "  /></td>
</tr>
<tr>
<td>Description</td>
<td><textarea name="Description"  /><?php echo $Data[6] ?></textarea></td>
</tr>
</table>
<input type="submit" value="Save" name="Update" Class="Button"/>
</form>
</body>
</html>

<?php
session_start();
require("RequestClass.php");
$RequestResponse = "";
if(isset($_POST["Cancel"])){
    header("location: Floors.php");    
}
else if(isset($_POST["submit"])) {
    $intakeName =  $_POST["intakeName"];
    //$roomName =  $_POST["roomName"];
    //echo $intakeName;
    //echo $roomName;
    $requestType =  $_POST["requestType"];
    $requestBy =  $_SESSION['username']; // THIS SHOULD BE REPLACED LATER BY SESSIONS
    $intakeID = $_POST["intakeName"]; // THIS SHOULD BE REPLACED LATER BY SESSIONS
    $requestDate = date("Y/m/d");   
    $DBconn = new RequestClass();
    $DBconn->connect(); 
    if($requestType == 'Room')
    {   
        $studentNumber =  (int)$_POST["studentNumber"];
        $powerCordNumber =  (int)$_POST["numberCord"];
        $startDate =  $_POST["startDate"];
        $endDate =  $_POST["endDate"];
        $startTime =  $_POST["startTime"];
        $endTime =  $_POST["endTime"];
              
        $RequestResponse = $DBconn->MakeRequest($requestType, 'NULL', $requestBy, $intakeID, $startDate, $endDate, $startTime, $endTime, $requestDate);    
    }
    else
    {        
        $roomName =  $_POST["roomName"];
        $RequestResponse = $DBconn->MakeRequest($requestType, $roomName, $requestBy, $intakeID, 'NULL', 'NULL', 'NULL', 'NULL', $requestDate);
    }    
    $DBconn->close();    

    if($RequestResponse == 'Request failed'){  
        echo $RequestResponse;
    }
    else{        
        $NewRequestID = $RequestResponse;
        
        $NumOfChairs = (int)$_POST["ChairNum"];
        $NumOfTables = (int)$_POST["TableNum"];
        $NumOfMonitors = (int)$_POST["MonitorNum"];
        $PowerCordAssets = (int)$_POST["PowerCordNum"];
        
        $NumOfLysol = (int)$_POST["Lysol"];
        $NumOfPaperTowel = (int)$_POST["PaperTowel"];
        $NumOfVinegarWater = (int)$_POST["VinegarWater"];
        $NumOfWindex = (int)$_POST["Windex"];

        if(isset($_POST["projectorInRoom"])){
            $projectorInRoom = 1;
        }else{
            $projectorInRoom = 0;
        }
        if(isset($_POST["digitalBoxInRoom"])){
            $digitalBoxInRoom = 1;
        }else{
            $digitalBoxInRoom = 0;
        }  

        if(isset($_POST["projectorAsset"])){
            $projectorAsset = 1;
        }else{
            $projectorAsset = 0;
        }
        if(isset($_POST["digitalBoxAsset"])){
            $digitalBoxAsset = 1;
        }else{
            $digitalBoxAsset = 0;
        }        

        $DBconn = new RequestClass();                    
        
        if($requestType == 'Room'){   
            $DBconn->connect();         
            $RequestDetailsResponse = $DBconn->SaveRoomRequestDetails ($NewRequestID, $studentNumber);
            $DBconn->close();
            if($RequestDetailsResponse == 'Request Details successfully inserted'){
                if($powerCordNumber > 0){
                    $DBconn->connect();
                    $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Power Cord', $powerCordNumber);
                    $DBconn->close();
                }
                if($projectorInRoom > 0){
                    $DBconn->connect();
                    $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Projector', $projectorInRoom);
                    $DBconn->close();
                }
                if($digitalBoxInRoom > 0){
                    $DBconn->connect();
                    $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Room Computer', $digitalBoxInRoom);
                    $DBconn->close();
                }
                else {echo $digitalBoxInRoom;}
            }
        }        
        else if($requestType == 'Asset'){
            if($NumOfChairs > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Chair', $NumOfChairs);
                $DBconn->close();
            }  
            if($NumOfTables > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Table', $NumOfTables);
                $DBconn->close();
            }
            if($NumOfMonitors > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Monitor', $NumOfMonitors);
                $DBconn->close();
            }
            if($PowerCordAssets > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Power Cord', $PowerCordAssets);
                $DBconn->close();
            }
            if($projectorAsset > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Projector', $projectorAsset);
                $DBconn->close();
            }
            if($digitalBoxAsset > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveAssetRequestDetails ($NewRequestID, 'Room Computer', $digitalBoxAsset);
                $DBconn->close();
            }          
        }        
        else if($requestType == 'Supply'){
            if($NumOfLysol > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveSupplyRequestDetails ($NewRequestID, 'Lysol', $NumOfLysol);
                $DBconn->close();
            } 
            if($NumOfPaperTowel > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveSupplyRequestDetails ($NewRequestID, 'Paper Towel', $NumOfPaperTowel);
                $DBconn->close();
            }
            if($NumOfVinegarWater > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveSupplyRequestDetails ($NewRequestID, 'Vinegar Water', $NumOfVinegarWater);
                $DBconn->close();
            }
            if($NumOfWindex > 0){
                $DBconn->connect();
                $RequestDetailsResponse = $DBconn->SaveSupplyRequestDetails ($NewRequestID, 'Windex', $NumOfWindex);
                $DBconn->close();
            }
        }        
    }                         
}
header("location: MyRequests.php");
?>
<?php 
session_start();
include("Master.php");
if(  $_SESSION['UserType'] == "Instructor")
{
  header("location: InstructorHome.php");
}
if(!isset($_SESSION['UserType']) || empty($_SESSION['UserType'])) {
  header("location:Login.php");
}
require("SupplyClass.php");
$DBconn = new SupplyClass();
$DBconn->connect();
$RoomDetails = $DBconn->readSupply();
$DBconn->close();
?>
<html>
    <header>  

         <link rel="stylesheet" type="text/css" href="TestStyle.css">  
               <link rel="stylesheet" type="text/css" href="Button.css">  
       <link rel="stylesheet" type="text/css" href="Requests.css"></header>
    <body>
 <a  href="#InsertSupply"> <button id="Insert" Class="Button" >Insert</button></a>
 <form action="Access_Supply.php" method="POST">
     <div id="InsertSupply" class="overlay">
	<div class="popup">
		<a class="close" href="#">&times;</a>
        <div>
        <table>
        <tr><td>Supply Name </td><td><input type="text" name="SupplyName"/></td></tr>
        <tr><td>Description </td><td><textarea name="Description"></textarea></td></tr>
        <tr><td>Quantity </td><td><input type="text" name="Quantity"/></td></tr>
        </table>
        <input type="Submit" class="Button" value="Save" name="InsertSupply" />
          </div>
        </div>
        </div>
        </div>
        </form>
    </body>
    </html>
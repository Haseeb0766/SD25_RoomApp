<?php
include("Master.php");
require("RequestClass.php");
parse_str($_SERVER['QUERY_STRING']);
$requestID = trim($RequestID);

$DBconn = new RequestClass();
$DBconn->connect();
echo "<br/>";
echo "<br/>";
$Request = $DBconn->ViewRequestByID($requestID);
$DBconn->close();
$DBconn = new RequestClass();
$DBconn->connect();
$RequestDetails = $Request . $DBconn->ViewRequestDetails($requestID);
$DBconn->close();
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="Requests.css">
</head>
<body>
<form action="RecommendedRooms.php" method="POST">
    <input type="submit" name="ViewRecommended" value="View Recommended" />
</form>
</body>
</html>
    
<?php
    echo $RequestDetails;
?>
<html>
    <header class="header" id="header">
     <script src="Scripts/jquery-3.1.1.js"></script>
         <link rel="stylesheet" type="text/css" href="Request.css"> 
           <link rel="stylesheet" type="text/css" href="Master.css"> 
    <div class="skew">
    
</div>
        <div class="header-inner">
            
          <h1 class="logo">
            <a href="http://localhost/SD25_Rooms_App/AdminHome.php">
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/a/a0/Robertson_College_Logo.jpeg/220px-Robertson_College_Logo.jpeg" alt="" style="width:100px; height:50px; margin-top: 10px; margin-left:10px;" />
            </h1>
            </a>
 
               <input type="checkbox" id="sidebartoggler" name="" value=""  />

<div class="page-wrap">

  <label for="sidebartoggler" class="toggle">☰</label>
  
<!--Place all webpage content into .page-content class-->


<!--Put .sidebar at bottom of webpage content, before </body>-->

  <div class="sidebar">
 <font color="red" style="text-align:center" >Manue</font>
    <ul>
      <li><a href="http://localhost/SD25_Rooms_App/Profile.php">My Profile</a></li>
      <li ><a href="http://localhost/SD25_Rooms_App/AdminHome.php">Home</a></li>
      <li><a href="http://localhost/SD25_Rooms_App/Request.php"> Make Request</a></li>
      <li><a href="http://localhost/SD25_Rooms_App/MyRequests.php">My Requests</a></li>
      <li><a href="http://localhost/SD25_Rooms_App/Login.php">Logout</a></li>
    </ul>
  </div><!--end sidebar-->
  
</div><!--end page-wrap-->


        </div>
    </div>
  </header>
</html>
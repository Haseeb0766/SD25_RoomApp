<?php
class LoginClass {
    private $servername = "localhost";
    private $username = "root";
    private $password = "haseebaqib12";
    private $dbname = "dbRoomManagement";
    private $conn;

    function __construct (){}
    function connect (){
        $this->conn = new mysqli($this->servername,
                                 $this->username,
                                 $this->password,
                                 $this->dbname);                                 
        if($this->conn->connect_error)
        {
            die("Connection Failed: " . $conn->connect_error);
        }
    }
    function close()
    {
        $this->conn->close();
    }
    function login ($username, $password){       
        $sql = "call spUser('" . $username . "',NULL,NULL,NULL,NULL,NULL,'"  . $password . "',NULL, NULL, 'login')";
        $result = $this->conn->query($sql);
 
        if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                $loginresult = $row["LoginResult"];
                $_SESSION['username'] = $row['Email'];
                $_SESSION['UserType'] = $row['UserType'];
                $_SESSION['FirstName'] = $row['FirstName'];
                $_SESSION['LastName'] = $row['LastName'];
                $_SESSION['ProfilePicture'] = $row['ProfilePicture'];
                
            }
if($loginresult == "Login successfull"){
if($_SESSION['UserType'] == "Instructor")
{
    header("location:InstructorHome.php");
}
if($_SESSION['UserType'] == "Admnistrator"){
 header("location: AdminHome.php");
}          
}else
{
    $ErrorMsg = "Wrong Username or Password";
    header("location: Login.php?ErrorMsg=" .$ErrorMsg);
}
            }      
        
    }
    function EditProfile($Email,$FirstName,$LastName,$ProfilePicture) {
        echo 'test';
  $sql = "call spUser('" . $Email . "','" . $FirstName . "','" . $LastName . "',NULL,NULL,NULL,NULL,'" . $ProfilePicture . "',NULL,'u')";
        $result = $this->conn->query($sql);
 
        if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                $UpdateResult = $row["Result"];                
            }
if($UpdateResult == "Update successfull"){
     $_SESSION['FirstName'] = $FirstName;
     $_SESSION['LastName'] = $LastName;
     $_SESSION['ProfilePicture'] = $ProfilePicture;
     $_SESSION['Description'] = $Description;
            header("location: Profile.php?PP=" . $ProfilePicture);
}else
{
    alert("Something Went Wrong");
    header("location: EditProfile.php");
}
            }  
    }
    function ChangePassword($Email, $OldPwrd, $NewPassword)
    {
          
  $sql = "call spChangePassword('" . $Email . "','" . $OldPwrd . "','" . $NewPassword . "')";
        $result = $this->conn->query($sql);
 
        if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                $UpdateResult = $row["Result"];                
            }
if($UpdateResult == "Password successfully changed"){
     header("location: Login.php");
}else
{
    header("Location:EditProfile.php?action=actionCheck&error=Wrong Password");
}
            }     
    }
    
}